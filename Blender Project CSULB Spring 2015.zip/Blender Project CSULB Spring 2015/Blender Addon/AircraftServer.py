bl_info = {
    "name": "Aircraft Server",
    "author": "CSULB CECS 491 Team 4",
    "version": (1, 0),
    "blender": (2, 70, 0),
    "location": "View3D > Add > Mesh > Aircraft Components",
    "description": "Links Blender to external application",
    "category": "Add Mesh",
}

import bpy
from bpy.props import *
import threading
import socket
import math
import numpy as np

#Global variables
socketThread = 0
s = 0
listenForData = False
unlink = False

#   createThread
#   - Creates the socket server where listening occurs in a new thread, this prevents Blender from stalling in a loop
def createThread():
    global socketThread, listenForData
    socketThread = threading.Thread(name='socketThread', target=listenToSocket)
    listenForData = True
    createSocketServer()
    socketThread.start()

#   listenToSocket
#   - Checks the listenForData flag, collecting any data received from the application and parsing it
def listenToSocket():
    global listenForData, s
    while listenForData:
        try:
            data, address = (s.recvfrom(4096))
            message = data.decode('utf-8')
            message = message.split(',')
            type = message.pop()
            if(type == "0"):
                createAirfoil(message, "Airfoil", [0,0,0])
            else:
                createWing(message, "Wing")
        except:
            pass

#   createAirfoil
#   - Uses the message received from the external application (vertices) to create an airfoil (2D) Blender Mesh Object
def createAirfoil(message, name, location):
    print("Creating airfoil...")
    #Mesh arrays
    verts = []
    edges = []
    faces = []
    e1 = []
    e2 = []
    #Mesh variables
    num = len(message)
    for i in range(0, num):
        if(i%2 == 0):
            e1.append(message[i])
        else:
            e2.append(message[i])
    #Fill vertices array
    for i in range(0, int(num/2)):
        x = 0
        y = float(e1[i])
        z = float(e2[i])
        vert = (x,y,z)
        verts.append(vert)
        if(i == int(num/2)-1):
            edges.append((i, 0))
        else:
            edges.append((i, i+1))
    #Create mesh and object
    mesh = bpy.data.meshes.new(name)
    object = bpy.data.objects.new(name, mesh)
    #Set mesh location
    object.location = location
    bpy.context.scene.objects.link(object)
    #Create mesh from python data
    mesh.from_pydata(verts, edges, faces)
    mesh.update(calc_edges=True)

#   createAirfoil
#   - Uses the message received from the external application (vertices) to create a wing (3D) Blender Mesh Object
def createWing(message, wingName):
    print("Creating wing...")
    #Mesh arrays
    verts = []
    faces = []
    ug = []
    lg = []
    ler = []
    topPointU = []
    topPointZ = []
    bottomPointU = []
    bottomPointZ = []
    bu = []
    bl = []
    hte = []
    sparX = []
    sparY = []
    sparZ = []
    scale = []
    for i in range(0, len(message), 14):
        ug.append(message[i])
        lg.append(message[i+1])
        ler.append(message[i+2])
        topPointU.append(message[i+3])
        topPointZ.append(message[i+4])
        bottomPointU.append(message[i+5])
        bottomPointZ.append(message[i+6])
        bu.append(message[i+7])
        bl.append(message[i+8])
        hte.append(message[i+9])
        sparX.append(message[i+10])
        sparY.append(message[i+11])
        sparZ.append(message[i+12])
        scale.append(message[i+13])
    data = ""
    for j in range(0, int(len(message)/14)):
        X = parametricFourier(float(ug[j]), float(lg[j]),
            float(ler[j]), float(topPointU[j]), float(topPointZ[j]),
            float(bottomPointU[j]), float(bottomPointZ[j]), float(bu[j]),
            float(bl[j]), float(hte[j]))
        n = 8
        gam = gam_(0, float(ug[j]), float(lg[j]))
        ww = 1 - 2 * 0
        previousX = X_of_W(gam, ww)
        previousY = float(hte[j]) * (1 - 2 * 0)
        data = data + str(previousX) + "," + str(previousY) + ","
        for i in range(1, 41):
            u = i/40
            gam = gam_(u, float(ug[j]), float(lg[j]))
            if(u < 0.5):
                ww = 1 - 2 * u
            else:
                ww = 2 * u - 1
            xx = X_of_W(gam, ww)
            zz = float(hte[j]) * (1 - 2 * u)
            for k in range(0, n):
                remain = 1
                zz = zz + X[k] * math.sin(remain * math.pi * (k+1) * u)
            data = data + str(xx) + "," + str(zz) + ","
    data = data.split(',')
    data.pop()
    airfoils = 0
    for k in range(0, len(data), 82):
        airfoils = airfoils + 1
    vCount = 0
    locIndex = 0
    for i in range(0, len(data), 2):
        x = float(sparX[locIndex])
        y = float(data[i]) * float(scale[locIndex]) + float(sparY[locIndex])
        z = float(data[i+1]) * float(scale[locIndex]) + float(sparZ[locIndex])
        vert = (x,y,z)
        verts.append(vert)
        vCount = vCount + 1
        if(vCount % 41 == 0):
            locIndex = locIndex + 1
    #Side Faces
    for i in range(0, airfoils):
        faces.append((41*i+0, 41*i+1, 41*i+2, 41*i+3, 41*i+4, 41*i+5, 41*i+6, 41*i+7, 41*i+8, 41*i+9, 41*i+10,
                      41*i+11, 41*i+12, 41*i+13, 41*i+14, 41*i+15, 41*i+16, 41*i+17, 41*i+18, 41*i+19, 41*i+20,
                      41*i+21, 41*i+22, 41*i+23, 41*i+24, 41*i+25, 41*i+26, 41*i+27, 41*i+28, 41*i+29, 41*i+30,
                      41*i+31, 41*i+32, 41*i+33, 41*i+34, 41*i+35, 41*i+36, 41*i+37, 41*i+38, 41*i+39, 41*i+40))
    vCount = 0
    for k in range(0, airfoils-1):
        for i in range(0, 41):
            #Wing panel faces
            face1 = (vCount, vCount+40, vCount+41, vCount+1)
            faces.append(face1)
            #Last panel face
            if(vCount % 41 == 0):
                lastFace = (vCount, vCount+41, vCount+81, vCount + 40)
                faces.append(lastFace)
            vCount = vCount + 1
    #Create mesh and object
    mesh = bpy.data.meshes.new(wingName)
    object = bpy.data.objects.new(wingName,mesh)
    #Set mesh location
    object.location = [0,0,0]
    bpy.context.scene.objects.link(object)
    #Create mesh from python data
    mesh.from_pydata(verts,[],faces)
    mesh.update(calc_edges=True)

#   createSocketServer
#   - Creates a socket server to be listened to for data from the external application
def createSocketServer():
    global s
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1) #Allows for reuse of the port if Blender crashes
    s.bind(('127.0.0.1', 7777))
    print("Server started")

#   parametricFourier
#   - Used to create 3D wings, takes in Fourier values to interpolate points
def parametricFourier(g_t, g_b, r, x_t, z_t, x_b, z_b, b_t, b_b, z):
    n = 8
    FF = np.matrix(np.zeros((n, n)))
    BB = np.array(np.zeros(n))
    for i in range(1,4):
        if(i == 1):
            wt = W_of_X(g_t, x_t)
            wb = W_of_X(g_b, x_b)
        else:
            ut = 0.5 * (1 - wt)
            gam = gam_(ut, g_t, g_b)
            wt = W_of_X(gam, x_t)
            ub = 0.5 * (1 + wb)
            gam = gam_(ub, g_t, g_b)
            wb = W_of_X(gam, x_b)
    gama = 0.5 * (g_t + g_b)
    for i in range(0, n):
        if(i == 0):
            uu = 0
            ww = 1
            zz = 0 + z
            dZdU = math.pi * math.tan(b_t * (math.pi / 180) * (1 - 4 * g_t))
        elif(i == 1 or i == 2):
            uu = ut
            ww = wt
            zz = z_t
            dZdU = 0
        elif(i == 3 or i == 4):
            uu = 0.5
            ww = 0
            zz = 0
            dZdU = -1 * math.sqrt(r * (1+8*gama) * math.pi**2)
        elif(i == 5 or i == 6):
            uu = ub
            ww = wb
            zz = z_b
            dZdU = 0
        elif(i == 7):
            uu = 1
            ww = 1
            zz = 0 - z
            dZdU = math.pi * math.tan(b_b * (math.pi/180)) * (1 - 4 * g_b)
        gam = gam_(uu, g_t, g_b)
        xx = X_of_W(gam, ww)
        if(i != 1 and i != 4 and i != 5):
            BB[i] = dZdU + 2 * z
        else:
            BB[i] = zz - z * (1 - 2 * uu)

        for j in range(0, n):
            remain = 1
            if(i != 1 and i != 4 and i != 5):
                FF[i,j] = math.pi * (j+1) * math.cos(remain * math.pi * (j+1) * uu)
            else:
                FF[i,j] = math.sin(remain * math.pi * (j+1) * uu)
    PP = np.linalg.solve(FF,BB)
    return PP

#Used in Parametric Fourier
def W_of_X(gamma, xx):
    expo = 0.56
    xe = xx ** expo
    w_of_x = xe - 1.3 * gamma * math.sin(math.pi * xe ** 2)
    for i in range(1,5):
        x1 = X_of_W(gamma, w_of_x)
        xe1 = x1 ** expo
        w_of_x = w_of_x + xe - xe1
    return w_of_x

#Used in Parametric Fourier
def X_of_W(gamma, ww):
    x_of_w = 1 - (1 - gamma) * math.cos(ww * math.pi / 2) - gamma * math.cos(ww * 3 * math.pi / 2)
    return x_of_w

#Used in Parametric Fourier
def gam_(uu, g_t, g_b):
    gam = g_b + (g_t - g_b) * (math.cos(uu * (math.pi / 2))) ** 2
    return gam

#   Main Class
#   - Handles the starting and closing of the socket server thread
#   - Registers the operator with Blender, so that it can be used and appears in the left sidebar
class aircraft_generator(bpy.types.Operator):
    bl_idname = "aircraft_generator.modal"
    bl_label = "Link to Aircraft Generator"

    def modal(self, context, event):
        global listenForData, s, unlink
        result = {'PASS_THROUGH'}
        if unlink:
            listenForData = False
            s.close()
            print("Server closed")
            socketThread.join()
            del s
            unlink = False
            result = {'CANCELLED'}
            self.report({'WARNING'}, "Aircraft Generator has been unlinked.")
        return result

    def invoke(self, context, event):
        global listenForData
        if listenForData == False:
            context.window_manager.event_timer_add(0.01, context.window)
            context.window_manager.modal_handler_add(self)
            createThread()
            return {'RUNNING_MODAL'}
        else:
            self.report({'WARNING'}, "Aircraft Generator is already linked.")
            return {'CANCELLED'}

#   Unlink Aircraft Generator
#   - Class to register an unlink button within Blender, this unlinks the connection between Blender and the external
#     application, closing the socket server and joining the thread
class unlinkAircraftGenerator(bpy.types.Operator):
    """Add a simple box mesh"""
    bl_idname = "aircraft_generator.close"
    bl_label = "Unlink Aircraft Generator"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        global unlink
        unlink = True
        return {'FINISHED'}

#   Aircraft Generator Panel
#   - This class sets up the UI in the left sidebar, linking the previous operators to buttons
class aircraftGeneratorPanel(bpy.types.Panel):
    bl_label = "Aircraft Generator"
    bl_space_type = "VIEW_3D"
    bl_region_type = "TOOLS"
    bl_category = 'Aircraft Generator'

    def draw(self, context):
        global listenForData
        layout = self.layout
        box = layout.box()
        if listenForData:
            box.label(text="Status: Linked")
        else:
            box.label(text="Status: Not Linked")
        box.operator("aircraft_generator.modal", icon='LOCKED')
        box.operator("aircraft_generator.close", icon='UNLOCKED')

def register():
    bpy.utils.register_module(__name__)

def unregister():
    bpy.utils.unregister_module(__name__)

if __name__ == "__main__":
    register()