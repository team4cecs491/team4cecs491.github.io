#   CSULB - Northrop Grumman Student Design Project
#   Standalone GUI Application
#   Written by Marvin Trajano, Lisa Tran, Victor Tran
#   Spring 2015

from tkinter import *
from tkinter import ttk
from tkinter import filedialog
import math
import tkinter.messagebox
import ParametricPolynomial as pp
import ParametricCubicSpline as pcs
import ParametricFourier as pf
import socket

#   Main Class
#   - Creates main window frame as well as sets up all the panels and components
class AircraftGenerator(ttk.Frame):
    def __init__(self, parent, isapp=True, name='aircraftgenerator'):
        main = ttk.Frame.__init__(self, name=name, borderwidth=10)
        self.parent = parent
        self.pack(expand=Y, fill=BOTH)
        self.master.title('Wing Generator')
        self.initUI()
        self.grid_columnconfigure(0, weight=1)
        self.centerWindow()
        #Exit check
        parent.protocol("WM_DELETE_WINDOW", self.exitCheck)

    #   initUI
    #   - Initializes the user interface, creating the panels and adds all components to the panels
    def initUI(self):
        self.tk.call('tk', 'windowingsystem')
        self.option_add("*tearOff", FALSE)
        menubar = Menu(self.parent)
        menu_file = Menu(menubar)
        menubar.add_cascade(menu=menu_file, label='File')
        menu_file.add_command(label='New', command=self.newFile)
        menu_file.add_command(label='Open', command=self.openFile)
        menu_file.add_command(label='Save', command=self.saveFile)
        menu_file.add_command(label='Save As', command=self.saveFileAs)
        menu_file.add_separator()
        menu_file.add_command(label='Export to Blender', command=self.export)
        menu_options = Menu(menubar)
        menubar.add_cascade(menu=menu_options, label='Options')
        menu_options.add_command(label='Change plot orientation', command=self.plotOrientation)
        menu_help = Menu(menubar)
        menubar.add_command(label='Help', command=self.help)
        menubar.add_command(label="About", command=self.about)

        #Station Data
        self.name = []
        self.topPointU = []
        self.topPointZ = []
        self.bottomPointU = []
        self.bottomPointZ = []
        self.ler = []
        self.hte = []
        self.bu = []
        self.bl = []
        self.ug = []
        self.lg = []
        self.sparX = []
        self.sparY = []
        self.sparZ = []
        self.scale = []

        #Main Panel
        self.parent.config(menu=menubar)
        s = ttk.Style()
        s.configure("TButton", padding=6, relief="flat")
        self.inputsF = ttk.Frame(self)
        self.inputsF.pack(side="left", fill="both", expand=True, padx=5)
        self.rowconfigure(1, pad=20)
        self.methodLF = ttk.LabelFrame(self, text='Generation Method', borderwidth=10)
        self.methodLF.grid(in_=self.inputsF, column=0, row=0, sticky=W+E)
        self.methodLF.grid_columnconfigure(0, weight=1)
        self.methodvalue=StringVar()
        self.method = ttk.Combobox(self, textvariable=self.methodvalue, state='readonly')
        self.method.grid(in_=self.methodLF, sticky=W+E)
        self.method['values'] = ('Select a method here.', '2D - Parametric Polynomial - Boundary Condition 1',
                                 '2D - Parametric Polynomial - Boundary Condition 2',
                                 '2D - Parametric Polynomial - Boundary Condition 3',
                                 '2D - Parametric Cubic Spline',
                                 '2D - Parametric Fourier',
                                 '3D - Parametric Fourier')
        self.method.current(0)
        self.method['values'] = ('2D - Parametric Polynomial - Boundary Condition 1',
                                 '2D - Parametric Polynomial - Boundary Condition 2',
                                 '2D - Parametric Polynomial - Boundary Condition 3',
                                 '2D - Parametric Cubic Spline',
                                 '2D - Parametric Fourier',
                                 '3D - Parametric Fourier')
        self.method.bind("<<ComboboxSelected>>", self.newsettings)
        self.plotLF = ttk.LabelFrame(self, text='Profile Plot', padding=20)
        self.plotLF.pack(side="top", padx=5)
        self.plot = Canvas(self, width=400, height=200, bg='white', highlightthickness=0, borderwidth=1)
        self.plot.grid(in_=self.plotLF, column=0, row=2)
        self.plot.create_rectangle(1, 1, 400, 200)
        self.settingsLF0 = ttk.LabelFrame(self, text='Settings', borderwidth=10)
        self.settingsLF0.grid(in_=self.inputsF,column=0, row=1, sticky=W+E)
        self.settingsLF0.grid_columnconfigure(0, weight=1, minsize=396)
        placeholder1 = ttk.Label(self, text='Select a generation method to configure settings.', anchor='center')
        placeholder1.grid(in_=self.settingsLF0, column=0, row=0, sticky=W+E)

        #Parametric Polynomial Boundary Condition 1 Panel
        self.settingsLF1 = ttk.LabelFrame(self, text='Settings', borderwidth=10)
        self.b1_label_u = ttk.Label(self, text='U(i)')
        self.b1_label_u.grid(row=0, column=1, in_=self.settingsLF1)
        self.b1_label_z = ttk.Label(self, text='Z(i)')
        self.b1_label_z.grid(row=0, column=2, in_=self.settingsLF1)
        self.b1_label_e = ttk.Label(self, text='Leading Edge:')
        self.b1_label_e.grid(row=1, column=0, in_=self.settingsLF1, sticky=W, padx=10)
        self.b1_entry_e_u = ttk.Entry(self, justify='center')
        self.b1_entry_e_u.grid(in_=self.settingsLF1, row=1, column=1, padx=2)
        self.b1_entry_e_z = ttk.Entry(self, justify='center')
        self.b1_entry_e_z.grid(in_=self.settingsLF1, row=1, column=2, padx=2)
        self.b1_label_0 = ttk.Label(self, text='Upper Trailing Edge:')
        self.b1_label_0.grid(row=2, column=0, in_=self.settingsLF1, sticky=W, padx=10)
        self.b1_entry_0_u = ttk.Entry(self, justify='center')
        self.b1_entry_0_u.grid(in_=self.settingsLF1, row=2, column=1, padx=2)
        self.b1_entry_0_z = ttk.Entry(self, justify='center')
        self.b1_entry_0_z.grid(in_=self.settingsLF1, row=2, column=2, padx=2)
        self.b1_label_1 = ttk.Label(self, text='Lower Trailing Edge:')
        self.b1_label_1.grid(row=3, column=0, in_=self.settingsLF1, sticky=W, padx=10)
        self.b1_entry_1_u = ttk.Entry(self, justify='center')
        self.b1_entry_1_u.grid(in_=self.settingsLF1, row=3, column=1, padx=2)
        self.b1_entry_1_z = ttk.Entry(self, justify='center')
        self.b1_entry_1_z.grid(in_=self.settingsLF1, row=3, column=2, padx=2)
        ttk.Separator(self.settingsLF1, orient=HORIZONTAL).grid(columnspan=3, sticky=W+E, pady=10)
        self.b1_label_r = ttk.Label(self, text='Radius:')
        self.b1_label_r.grid(row=5, column=0, in_=self.settingsLF1, sticky=W, padx=10)
        self.b1_entry_r = ttk.Entry(self, justify='center')
        self.b1_entry_r.grid(in_=self.settingsLF1, row=5, column=1, padx=2)
        self.b1_label_b0 = ttk.Label(self, text='Beta Upper Angle:')
        self.b1_label_b0.grid(row=6, column=0, in_=self.settingsLF1, sticky=W, padx=10)
        self.b1_entry_b0 = ttk.Entry(self, justify='center')
        self.b1_entry_b0.grid(in_=self.settingsLF1, row=6, column=1, padx=2)
        self.b1_label_b1 = ttk.Label(self, text='Beta Lower Angle:')
        self.b1_label_b1.grid(row=7, column=0, in_=self.settingsLF1, sticky=W, padx=10)
        self.b1_entry_b1 = ttk.Entry(self, justify='center')
        self.b1_entry_b1.grid(in_=self.settingsLF1, row=7, column=1, padx=2)
        self.b1_label_g = ttk.Label(self, text='Gamma:')
        self.b1_label_g.grid(row=8, column=0, in_=self.settingsLF1, sticky=W, padx=10)
        self.b1_entry_g = ttk.Entry(self, justify='center')
        self.b1_entry_g.grid(in_=self.settingsLF1, row=8, column=1, padx=2)

        #Parametric Polynomial Boundary Condition 2 Panel
        self.settingsLF2 = ttk.LabelFrame(self, text='Settings', borderwidth=10)
        self.b2_label_u = ttk.Label(self, text='U(i)')
        self.b2_label_u.grid(row=0, column=1, in_=self.settingsLF2)
        self.b2_label_z = ttk.Label(self, text='Z(i)')
        self.b2_label_z.grid(row=0, column=2, in_=self.settingsLF2)
        self.b2_label_e = ttk.Label(self, text='Leading Edge:')
        self.b2_label_e.grid(row=1, column=0, in_=self.settingsLF2, sticky=W, padx=10)
        self.b2_entry_e_u = ttk.Entry(self, justify='center')
        self.b2_entry_e_u.grid(in_=self.settingsLF2, row=1, column=1, padx=2)
        self.b2_entry_e_z = ttk.Entry(self, justify='center')
        self.b2_entry_e_z.grid(in_=self.settingsLF2, row=1, column=2, padx=2)
        self.b2_label_0 = ttk.Label(self, text='Upper Trailing Edge:')
        self.b2_label_0.grid(row=2, column=0, in_=self.settingsLF2, sticky=W, padx=10)
        self.b2_entry_0_u = ttk.Entry(self, justify='center')
        self.b2_entry_0_u.grid(in_=self.settingsLF2, row=2, column=1, padx=2)
        self.b2_entry_0_z = ttk.Entry(self, justify='center')
        self.b2_entry_0_z.grid(in_=self.settingsLF2, row=2, column=2, padx=2)
        self.b2_label_1 = ttk.Label(self, text='Lower Trailing Edge:')
        self.b2_label_1.grid(row=3, column=0, in_=self.settingsLF2, sticky=W, padx=10)
        self.b2_entry_1_u = ttk.Entry(self, justify='center')
        self.b2_entry_1_u.grid(in_=self.settingsLF2, row=3, column=1, padx=2)
        self.b2_entry_1_z = ttk.Entry(self, justify='center')
        self.b2_entry_1_z.grid(in_=self.settingsLF2, row=3, column=2, padx=2)
        self.b2_label_t = ttk.Label(self, text='Top Point:')
        self.b2_label_t.grid(row=4, column=0, in_=self.settingsLF2, sticky=W, padx=10)
        self.b2_entry_t_u = ttk.Entry(self, justify='center')
        self.b2_entry_t_u.grid(in_=self.settingsLF2, row=4, column=1, padx=2)
        self.b2_entry_t_z = ttk.Entry(self, justify='center')
        self.b2_entry_t_z.grid(in_=self.settingsLF2, row=4, column=2, padx=2)
        self.b2_label_b = ttk.Label(self, text='Bottom Point:')
        self.b2_label_b.grid(row=5, column=0, in_=self.settingsLF2, sticky=W, padx=10)
        self.b2_entry_b_u = ttk.Entry(self, justify='center')
        self.b2_entry_b_u.grid(in_=self.settingsLF2, row=5, column=1, padx=2)
        self.b2_entry_b_z = ttk.Entry(self, justify='center')
        self.b2_entry_b_z.grid(in_=self.settingsLF2, row=5, column=2, padx=2)
        ttk.Separator(self.settingsLF2, orient=HORIZONTAL).grid(columnspan=3, sticky=W+E, pady=10)
        self.b2_label_r = ttk.Label(self, text='Radius:')
        self.b2_label_r.grid(row=7, column=0, in_=self.settingsLF2, sticky=W, padx=10)
        self.b2_entry_r = ttk.Entry(self, justify='center')
        self.b2_entry_r.grid(in_=self.settingsLF2, row=7, column=1, padx=2)
        self.b2_label_b0 = ttk.Label(self, text='Beta Upper Angle:')
        self.b2_label_b0.grid(row=8, column=0, in_=self.settingsLF2, sticky=W, padx=10)
        self.b2_entry_b0 = ttk.Entry(self, justify='center')
        self.b2_entry_b0.grid(in_=self.settingsLF2, row=8, column=1, padx=2)
        self.b2_label_b1 = ttk.Label(self, text='Beta Lower Angle:')
        self.b2_label_b1.grid(row=9, column=0, in_=self.settingsLF2, sticky=W, padx=10)
        self.b2_entry_b1 = ttk.Entry(self, justify='center')
        self.b2_entry_b1.grid(in_=self.settingsLF2, row=9, column=1, padx=2)
        self.b2_label_g = ttk.Label(self, text='Gamma:')
        self.b2_label_g.grid(row=10, column=0, in_=self.settingsLF2, sticky=W, padx=10)
        self.b2_entry_g = ttk.Entry(self, justify='center')
        self.b2_entry_g.grid(in_=self.settingsLF2, row=10, column=1, padx=2)

        #Parametric Polynomial Boundary Condition 3 Panel
        self.settingsLF3 = ttk.LabelFrame(self, text='Settings', borderwidth=10)
        self.b3_label_u = ttk.Label(self, text='U(i)')
        self.b3_label_u.grid(row=0, column=1, in_=self.settingsLF3)
        self.b3_label_z = ttk.Label(self, text='Z(i)')
        self.b3_label_z.grid(row=0, column=2, in_=self.settingsLF3)
        self.b3_label_e = ttk.Label(self, text='Leading Edge:')
        self.b3_label_e.grid(row=1, column=0, in_=self.settingsLF3, sticky=W, padx=10)
        self.b3_entry_e_u = ttk.Entry(self, justify='center')
        self.b3_entry_e_u.grid(in_=self.settingsLF3, row=1, column=1, padx=2)
        self.b3_entry_e_z = ttk.Entry(self, justify='center')
        self.b3_entry_e_z.grid(in_=self.settingsLF3, row=1, column=2, padx=2)
        self.b3_label_0 = ttk.Label(self, text='Upper Trailing Edge:')
        self.b3_label_0.grid(row=2, column=0, in_=self.settingsLF3, sticky=W, padx=10)
        self.b3_entry_0_u = ttk.Entry(self, justify='center')
        self.b3_entry_0_u.grid(in_=self.settingsLF3, row=2, column=1, padx=2)
        self.b3_entry_0_z = ttk.Entry(self, justify='center')
        self.b3_entry_0_z.grid(in_=self.settingsLF3, row=2, column=2, padx=2)
        self.b3_label_1 = ttk.Label(self, text='Lower Trailing Edge:')
        self.b3_label_1.grid(row=3, column=0, in_=self.settingsLF3, sticky=W, padx=10)
        self.b3_entry_1_u = ttk.Entry(self, justify='center')
        self.b3_entry_1_u.grid(in_=self.settingsLF3, row=3, column=1, padx=2)
        self.b3_entry_1_z = ttk.Entry(self, justify='center')
        self.b3_entry_1_z.grid(in_=self.settingsLF3, row=3, column=2, padx=2)
        self.b3_label_t = ttk.Label(self, text='Top Point:')
        self.b3_label_t.grid(row=4, column=0, in_=self.settingsLF3, sticky=W, padx=10)
        self.b3_entry_t_u = ttk.Entry(self, justify='center')
        self.b3_entry_t_u.grid(in_=self.settingsLF3, row=4, column=1, padx=2)
        self.b3_entry_t_z = ttk.Entry(self, justify='center')
        self.b3_entry_t_z.grid(in_=self.settingsLF3, row=4, column=2, padx=2)
        self.b3_label_b = ttk.Label(self, text='Bottom Point:')
        self.b3_label_b.grid(row=5, column=0, in_=self.settingsLF3, sticky=W, padx=10)
        self.b3_entry_b_u = ttk.Entry(self, justify='center')
        self.b3_entry_b_u.grid(in_=self.settingsLF3, row=5, column=1, padx=2)
        self.b3_entry_b_z = ttk.Entry(self, justify='center')
        self.b3_entry_b_z.grid(in_=self.settingsLF3, row=5, column=2, padx=2)
        ttk.Separator(self.settingsLF3, orient=HORIZONTAL).grid(columnspan=3, sticky=W+E, pady=10)
        self.b3_label_0_r = ttk.Label(self, text='Upper Radius:')
        self.b3_label_0_r.grid(row=7, column=0, in_=self.settingsLF3, sticky=W, padx=10)
        self.b3_entry_0_r = ttk.Entry(self, justify='center')
        self.b3_entry_0_r.grid(in_=self.settingsLF3, row=7, column=1, padx=2)
        self.b3_label_1_r = ttk.Label(self, text='Lower Radius:')
        self.b3_label_1_r.grid(row=8, column=0, in_=self.settingsLF3, sticky=W, padx=10)
        self.b3_entry_1_r = ttk.Entry(self, justify='center')
        self.b3_entry_1_r.grid(in_=self.settingsLF3, row=8, column=1, padx=2)
        self.b3_label_b0 = ttk.Label(self, text='Beta Upper Angle:')
        self.b3_label_b0.grid(row=9, column=0, in_=self.settingsLF3, sticky=W, padx=10)
        self.b3_entry_b0 = ttk.Entry(self, justify='center')
        self.b3_entry_b0.grid(in_=self.settingsLF3, row=9, column=1, padx=2)
        self.b3_label_b1 = ttk.Label(self, text='Beta Lower Angle:')
        self.b3_label_b1.grid(row=10, column=0, in_=self.settingsLF3, sticky=W, padx=10)
        self.b3_entry_b1 = ttk.Entry(self, justify='center')
        self.b3_entry_b1.grid(in_=self.settingsLF3, row=10, column=1, padx=2)
        self.b3_label_0_g = ttk.Label(self, text='Upper Gamma:')
        self.b3_label_0_g.grid(row=11, column=0, in_=self.settingsLF3, sticky=W, padx=10)
        self.b3_entry_0_g = ttk.Entry(self, justify='center')
        self.b3_entry_0_g.grid(in_=self.settingsLF3, row=11, column=1, padx=2)
        self.b3_label_1_g = ttk.Label(self, text='Lower Gamma:')
        self.b3_label_1_g.grid(row=12, column=0, in_=self.settingsLF3, sticky=W, padx=10)
        self.b3_entry_1_g = ttk.Entry(self, justify='center')
        self.b3_entry_1_g.grid(in_=self.settingsLF3, row=12, column=1, padx=2)

        #Parametric Cubic Spline
        self.settingsLF4 = ttk.LabelFrame(self, text='Settings', borderwidth=10)
        pointsLabel = ttk.Label(self, text='Points').grid(in_=self.settingsLF4, row=0, column=0)
        self.listbox = Listbox(self, height=10, width = 20)
        self.listbox.grid(in_=self.settingsLF4, row=1, column=0, rowspan=5, padx=5)
        #0, 0.03, 0.19, 0.5, 0.88, 1.0
        #0, 0.0007, -0.049, 0.0, 0.0488, 0
        #fill the listbox for testing purposes
        self.listbox.insert(END, " 0, 0")
        self.listbox.insert(END, " 0.03, 0.0007")
        self.listbox.insert(END, " 0.19, -0.049")
        self.listbox.insert(END, " 0.5, 0.0")
        self.listbox.insert(END, " 0.88, 0.0488")
        self.listbox.insert(END, " 1.0, 0")
        self.curIndex = None
        self.listbox.bind('<Button-1>', self.setCurrent)
        self.listbox.bind('<B1-Motion>', self.shiftSelection)
        self.addPoint = ttk.Button(self, text='Add Point', command=lambda: self.addListPoint())
        self.addPoint.grid(in_=self.settingsLF4, sticky=W+E, row=1, column=1, padx=10, pady=5)
        self.deletePoint = ttk.Button(self, text='Delete Point', command=lambda: self.deleteListPoint())
        self.deletePoint.grid(in_=self.settingsLF4, sticky=W+E, row=2, column=1, padx=10)
        self.leftConstraintValue=StringVar()
        self.leftConstraint = ttk.Combobox(self, textvariable=self.leftConstraintValue, state='readonly')
        self.leftConstraint.grid(in_=self.settingsLF4, sticky=W+E, row=4, column=1, padx=10, pady=5)
        self.leftConstraint['values'] = ('Left End Constraint', 'Stiff', 'Flat', 'Flexible')
        self.leftConstraint.current(0)
        self.seperatorC = ttk.Frame(self, borderwidth=15)
        self.seperatorC.grid(in_=self.settingsLF4, row=3, column=1, sticky=W+E)
        self.seperatorC.grid_columnconfigure(0, weight=1)
        ttk.Separator(self.seperatorC, orient=HORIZONTAL).grid(sticky=W+E)
        self.rightConstraintValue=StringVar()
        self.rightConstraint = ttk.Combobox(self, textvariable=self.rightConstraintValue, state='readonly')
        self.rightConstraint.grid(in_=self.settingsLF4, sticky=W+E, row=5, column=1, padx=10, pady=5)
        self.rightConstraint['values'] = ('Right End Constraint', 'Stiff', 'Flat', 'Flexible')
        self.rightConstraint.current(0)
        self.leftConstraintLabel = ttk.Label(self, text='Left Slope:')
        self.leftConstraintEntry = ttk.Entry(self)
        self.rightConstraintLabel = ttk.Label(self, text='Right Slope:')
        self.rightConstraintEntry = ttk.Entry(self)

        #2D Parametric Fourier Panel
        self.settingsLF5 = ttk.LabelFrame(self, text='Settings', borderwidth=10)
        self.f_label_u = ttk.Label(self, text='U(i)')
        self.f_label_u.grid(row=0, column=1, in_=self.settingsLF5)
        self.f_label_z = ttk.Label(self, text='Z(i)')
        self.f_label_z.grid(row=0, column=2, in_=self.settingsLF5)
        self.f_label_t = ttk.Label(self, text='Top Point:')
        self.f_label_t.grid(row=1, column=0, in_=self.settingsLF5, sticky=W, padx=10)
        self.f_entry_t_u = ttk.Entry(self, justify='center')
        self.f_entry_t_u.grid(in_=self.settingsLF5, row=1, column=1, padx=2)
        self.f_entry_t_z = ttk.Entry(self, justify='center')
        self.f_entry_t_z.grid(in_=self.settingsLF5, row=1, column=2, padx=2)
        self.f_label_b = ttk.Label(self, text='Bottom Point:')
        self.f_label_b.grid(row=3, column=0, in_=self.settingsLF5, sticky=W, padx=10)
        self.f_entry_b_u = ttk.Entry(self, justify='center')
        self.f_entry_b_u.grid(in_=self.settingsLF5, row=3, column=1, padx=2)
        self.f_entry_b_z = ttk.Entry(self, justify='center')
        self.f_entry_b_z.grid(in_=self.settingsLF5, row=3, column=2, padx=2)
        ttk.Separator(self.settingsLF5, orient=HORIZONTAL).grid(columnspan=3, sticky=W+E, pady=10)
        self.f_label_le_r = ttk.Label(self, text='Leading Edge Radius:')
        self.f_label_le_r.grid(row=5, column=0, in_=self.settingsLF5, sticky=W, padx=10)
        self.f_entry_le_r = ttk.Entry(self, justify='center')
        self.f_entry_le_r.grid(in_=self.settingsLF5, row=5, column=1, padx=2)
        self.f_label_hte = ttk.Label(self, text='Half Trailing Edge:')
        self.f_label_hte.grid(row=6, column=0, in_=self.settingsLF5, sticky=W, padx=10)
        self.f_entry_hte = ttk.Entry(self, justify='center')
        self.f_entry_hte.grid(in_=self.settingsLF5, row=6, column=1, padx=2)
        self.f_label_b0 = ttk.Label(self, text='Beta Upper Angle:')
        self.f_label_b0.grid(row=7, column=0, in_=self.settingsLF5, sticky=W, padx=10)
        self.f_entry_b0 = ttk.Entry(self, justify='center')
        self.f_entry_b0.grid(in_=self.settingsLF5, row=7, column=1, padx=2)
        self.f_label_b1 = ttk.Label(self, text='Beta Lower Angle:')
        self.f_label_b1.grid(row=8, column=0, in_=self.settingsLF5, sticky=W, padx=10)
        self.f_entry_b1 = ttk.Entry(self, justify='center')
        self.f_entry_b1.grid(in_=self.settingsLF5, row=8, column=1, padx=2)
        self.f_label_0_g = ttk.Label(self, text='Upper Gamma:')
        self.f_label_0_g.grid(row=9, column=0, in_=self.settingsLF5, sticky=W, padx=10)
        self.f_entry_0_g = ttk.Entry(self, justify='center')
        self.f_entry_0_g.grid(in_=self.settingsLF5, row=9, column=1, padx=2)
        self.f_label_1_g = ttk.Label(self, text='Lower Gamma:')
        self.f_label_1_g.grid(row=10, column=0, in_=self.settingsLF5, sticky=W, padx=10)
        self.f_entry_1_g = ttk.Entry(self, justify='center')
        self.f_entry_1_g.grid(in_=self.settingsLF5, row=10, column=1, padx=2)

        #3D Parametric Fourier Panel
        self.settingsLF6 = ttk.LabelFrame(self, text='Settings', borderwidth=10)
        pointsLabel = ttk.Label(self, text='Stations').grid(in_=self.settingsLF6, row=0, column=0)
        self.listboxF = Listbox(self, height=10, width = 20)
        self.listboxF.grid(in_=self.settingsLF6, row=1, column=0, rowspan=5, padx=5)
        #fill the listbox for testing purposes
        self.listboxF.insert(END, "Left Tip")
        self.name.append("Left Tip")
        self.topPointU.append(0.31)
        self.topPointZ.append(0.075)
        self.bottomPointU.append(0.44)
        self.bottomPointZ.append(-0.107)
        self.ler.append(0.02)
        self.hte.append(0.0005)
        self.bu.append(9.5)
        self.bl.append(10.0)
        self.ug.append(0)
        self.lg.append(0.13)
        self.sparX.append(4)
        self.sparY.append(1)
        self.sparZ.append(0)
        self.scale.append(1)
        self.listboxF.insert(END, "Left Panel")
        self.name.append("Left Panel")
        self.topPointU.append(0.31)
        self.topPointZ.append(0.075)
        self.bottomPointU.append(0.44)
        self.bottomPointZ.append(-0.107)
        self.ler.append(0.02)
        self.hte.append(0.0005)
        self.bu.append(9.5)
        self.bl.append(10.0)
        self.ug.append(0)
        self.lg.append(0.13)
        self.sparX.append(1)
        self.sparY.append(-0.5)
        self.sparZ.append(0)
        self.scale.append(2)
        self.listboxF.insert(END, "Root")
        self.name.append("Root")
        self.topPointU.append(0.31)
        self.topPointZ.append(0.075)
        self.bottomPointU.append(0.44)
        self.bottomPointZ.append(-0.107)
        self.ler.append(0.02)
        self.hte.append(0.0005)
        self.bu.append(9.5)
        self.bl.append(10.0)
        self.ug.append(0)
        self.lg.append(0.13)
        self.sparX.append(0)
        self.sparY.append(-1)
        self.sparZ.append(0)
        self.scale.append(4)
        self.listboxF.insert(END, "Right Panel")
        self.name.append("Right Panel")
        self.topPointU.append(0.31)
        self.topPointZ.append(0.075)
        self.bottomPointU.append(0.44)
        self.bottomPointZ.append(-0.107)
        self.ler.append(0.02)
        self.hte.append(0.0005)
        self.bu.append(9.5)
        self.bl.append(10.0)
        self.ug.append(0)
        self.lg.append(0.13)
        self.sparX.append(-1)
        self.sparY.append(-0.5)
        self.sparZ.append(0)
        self.scale.append(2)
        self.listboxF.insert(END, "Right Tip")
        self.name.append("Right Tip")
        self.topPointU.append(0.31)
        self.topPointZ.append(0.075)
        self.bottomPointU.append(0.44)
        self.bottomPointZ.append(-0.107)
        self.ler.append(0.02)
        self.hte.append(0.0005)
        self.bu.append(9.5)
        self.bl.append(10.0)
        self.ug.append(0)
        self.lg.append(0.13)
        self.sparX.append(-4)
        self.sparY.append(1)
        self.sparZ.append(0)
        self.scale.append(1)
        self.curIndexF = None
        self.listboxF.bind('<Button-1>', self.setCurrentF)
        self.addStationF = ttk.Button(self, text='Add Station', command=lambda: self.addStation())
        self.addStationF.grid(in_=self.settingsLF6, sticky=W+E, row=1, column=1, padx=10, pady=5)
        self.editStationF = ttk.Button(self, text='Edit Station', command=lambda: self.editStation())
        self.editStationF.grid(in_=self.settingsLF6, sticky=W+E, row=2, column=1, padx=10, pady=5)
        self.deleteStationF = ttk.Button(self, text='Delete Station', command=lambda: self.deleteStation())
        self.deleteStationF.grid(in_=self.settingsLF6, sticky=W+E, row=3, column=1, padx=10, pady=5)
        self.seperatorF = ttk.Frame(self, borderwidth=15)
        self.seperatorF.grid(in_=self.inputsF, column=0, row=3, sticky=W+E)
        self.seperatorF.grid_columnconfigure(0, weight=1)
        ttk.Separator(self.seperatorF, orient=HORIZONTAL).grid(sticky=W+E)
        self.buttonsF = ttk.Frame(self)
        self.buttonsF.grid(in_=self.inputsF, row=4, column=0, sticky=W+E)
        self.buttonsF.grid_columnconfigure(0, weight=1)
        self.applyB = ttk.Button(self, text='Apply Settings', command=lambda: self.apply())
        self.applyB.grid(in_=self.buttonsF, sticky=W+E)
        self.exportB = ttk.Button(self, text='Export to Blender', command=lambda: self.export())
        self.exportB.grid(in_=self.buttonsF, sticky=W+E)

    #   addStation
    #   - Creates a new window to prompt the user for data for a new station
    def addStation(self):
        w = 408
        h = 470
        self.stationWindow = Tk()
        self.stationWindow.wm_title("Add Station")
        nameLabel = ttk.Label(self.stationWindow, text="Name:")
        nameLabel.grid(in_=self.stationWindow, row=0, column=0, pady=10, sticky=E)
        self.nameEntry = ttk.Entry(self.stationWindow, justify='center')
        self.nameEntry.grid(padx=5, row=0, column=1, pady=10)
        u_label = ttk.Label(self.stationWindow, text="U:")
        u_label.grid(in_=self.stationWindow, row=1, column=1, padx=3, pady=3)
        z_label = ttk.Label(self.stationWindow, text="Z:")
        z_label.grid(in_=self.stationWindow, row=1, column=2)
        topPoint = ttk.Label(self.stationWindow, text="Top Point:")
        topPoint.grid(in_=self.stationWindow, row=2, column=0, padx=3, pady=3, sticky=E)
        self.topPointUEntry = ttk.Entry(self.stationWindow, justify='center')
        self.topPointUEntry.grid(padx=5, row=2, column=1, pady=3)
        self.topPointZEntry = ttk.Entry(self.stationWindow, justify='center')
        self.topPointZEntry.grid(padx=5, row=2, column=2, pady=3)
        bottomPoint = ttk.Label(self.stationWindow, text="Bottom Point:")
        bottomPoint.grid(in_=self.stationWindow, row=3, column=0, padx=3, pady=3, sticky=E)
        self.bottomPointUEntry = ttk.Entry(self.stationWindow, justify='center')
        self.bottomPointUEntry.grid(padx=5, row=3, column=1, pady=3)
        self.bottomPointZEntry = ttk.Entry(self.stationWindow, justify='center')
        self.bottomPointZEntry.grid(padx=5, row=3, column=2, pady=3)
        ttk.Separator(self.stationWindow, orient=HORIZONTAL).grid(columnspan=3, sticky=W+E, pady=10)
        rLabel = ttk.Label(self.stationWindow, text="Leading Edge Radius:")
        rLabel.grid(in_=self.stationWindow, row=5, column=0, padx=3, pady=3, sticky=E)
        self.rEntry = ttk.Entry(self.stationWindow, justify='center')
        self.rEntry.grid(padx=5, row=5, column=1, pady=3)
        hteLabel = ttk.Label(self.stationWindow, text="Half Trailing Edge:")
        hteLabel.grid(in_=self.stationWindow, row=6, column=0, padx=3, pady=3, sticky=E)
        self.hteEntry = ttk.Entry(self.stationWindow, justify='center')
        self.hteEntry.grid(padx=5, row=6, column=1, pady=3)
        buLabel = ttk.Label(self.stationWindow, text="Beta Upper Angle:")
        buLabel.grid(in_=self.stationWindow, row=7, column=0, padx=3, pady=3, sticky=E)
        self.buEntry = ttk.Entry(self.stationWindow, justify='center')
        self.buEntry.grid(padx=5, row=7, column=1, pady=3)
        blLabel = ttk.Label(self.stationWindow, text="Beta Lower Angle:")
        blLabel.grid(in_=self.stationWindow, row=8, column=0, padx=3, pady=3, sticky=E)
        self.blEntry = ttk.Entry(self.stationWindow, justify='center')
        self.blEntry.grid(padx=5, row=8, column=1, pady=3)
        ugLabel = ttk.Label(self.stationWindow, text="Upper Gamma:")
        ugLabel.grid(in_=self.stationWindow, row=9, column=0, padx=3, pady=3, sticky=E)
        self.ugEntry = ttk.Entry(self.stationWindow, justify='center')
        self.ugEntry.grid(padx=5, row=9, column=1, pady=3)
        lgLabel = ttk.Label(self.stationWindow, text="Lower Gamma:")
        lgLabel.grid(in_=self.stationWindow, row=10, column=0, padx=3, pady=3, sticky=E)
        self.lgEntry = ttk.Entry(self.stationWindow, justify='center')
        self.lgEntry.grid(padx=5, row=10, column=1, pady=3)
        ttk.Separator(self.stationWindow, orient=HORIZONTAL).grid(columnspan=3, sticky=W+E, pady=10)
        sparXLabel = ttk.Label(self.stationWindow, text="Spar Backbone X")
        sparXLabel.grid(in_=self.stationWindow, row=12, column=0, padx=20, pady=3, sticky=W+E)
        sparYLabel = ttk.Label(self.stationWindow, text="Spar Backbone Y")
        sparYLabel.grid(in_=self.stationWindow, row=12, column=1, padx=20, pady=3, sticky=W+E)
        sparZLabel = ttk.Label(self.stationWindow, text="Spar Backbone Z")
        sparZLabel.grid(in_=self.stationWindow, row=12, column=2, padx=20, pady=3, sticky=W+E)
        self.sparXEntry = ttk.Entry(self.stationWindow, justify='center')
        self.sparXEntry.grid(padx=5, row=13, column=0, pady=3)
        self.sparYEntry = ttk.Entry(self.stationWindow, justify='center')
        self.sparYEntry.grid(padx=5, row=13, column=1, pady=3)
        self.sparZEntry = ttk.Entry(self.stationWindow, justify='center')
        self.sparZEntry.grid(padx=5, row=13, column=2, pady=3)
        scaleLabel = ttk.Label(self.stationWindow, text="Scale:")
        scaleLabel.grid(in_=self.stationWindow, row=14, column=0, padx=20, pady=3, sticky=E)
        self.scaleEntry = ttk.Entry(self.stationWindow, justify='center')
        self.scaleEntry.grid(padx=5, row=14, column=1, pady=3)
        add = ttk.Button(self.stationWindow, text="Add", command=lambda: self.addStationInputs())
        add.grid(row=15, column=1, sticky=W+E, padx=10, pady=10)
        cancel = ttk.Button(self.stationWindow, text="Cancel", command=lambda: self.cancelF())
        cancel.grid(row=15, column=2, sticky=W+E, padx=10, pady=10)
        ws = self.stationWindow.winfo_screenwidth()
        hs = self.stationWindow.winfo_screenheight()
        x = (ws - w) / 2
        y = (hs - h) / 2
        self.stationWindow.geometry('%dx%d+%d+%d' % (w, h, x, y))

    #   addStationInputs
    #   - Called when the "Add" button is pressed, takes all the inputs and puts them into the appropriate arrays used
    #     to store data, throws an Error Dialog if the input values are not acceptable
    def addStationInputs(self):
        if self.nameEntry.get():
            try:
                float(self.topPointUEntry.get())
                float(self.topPointZEntry.get())
                float(self.bottomPointUEntry.get())
                float(self.bottomPointZEntry.get())
                float(self.rEntry.get())
                float(self.hteEntry.get())
                float(self.buEntry.get())
                float(self.blEntry.get())
                float(self.ugEntry.get())
                float(self.lgEntry.get())
                float(self.sparXEntry.get())
                float(self.sparYEntry.get())
                float(self.sparZEntry.get())
                float(self.scaleEntry.get())
                self.name.append(self.nameEntry.get())
                self.topPointU.append(self.topPointUEntry.get())
                self.topPointZ.append(self.topPointZEntry.get())
                self.bottomPointU.append(self.bottomPointUEntry.get())
                self.bottomPointZ.append(self.bottomPointZEntry.get())
                self.ler.append(self.rEntry.get())
                self.hte.append(self.hteEntry.get())
                self.bu.append(self.buEntry.get())
                self.bl.append(self.blEntry.get())
                self.ug.append(self.ugEntry.get())
                self.lg.append(self.lgEntry.get())
                self.sparX.append(self.sparXEntry.get())
                self.sparY.append(self.sparYEntry.get())
                self.sparZ.append(self.sparZEntry.get())
                self.scale.append(self.scaleEntry.get())
                self.listboxF.insert(END, self.nameEntry.get())
            except ValueError:
                tkinter.messagebox.showerror("Error", "Entries must consist of numerical values and must not be blank.")
        else:
            tkinter.messagebox.showerror("Error", "Enter a name.")
        self.stationWindow.destroy()

    #   deleteStation
    #   - Called then the "Delete Station" button is pressed, removes the data for the selected station, throws an Error
    #     Dialog if no station is selected
    def deleteStation(self):
        try:
            self.name.pop(self.curIndexF)
            self.topPointU.pop(self.curIndexF)
            self.topPointZ.pop(self.curIndexF)
            self.bottomPointU.pop(self.curIndexF)
            self.bottomPointZ.pop(self.curIndexF)
            self.ler.pop(self.curIndexF)
            self.hte.pop(self.curIndexF)
            self.bu.pop(self.curIndexF)
            self.bl.pop(self.curIndexF)
            self.ug.pop(self.curIndexF)
            self.lg.pop(self.curIndexF)
            self.sparX.pop(self.curIndexF)
            self.sparY.pop(self.curIndexF)
            self.sparZ.pop(self.curIndexF)
            self.scale.pop(self.curIndexF)
            self.listboxF.delete(self.curIndexF)
        except:
            tkinter.messagebox.showwarning("Warning", "Must select to delete!")

    #   editStation
    #   - Called the the "Edit Station" button is pressed, creates a new window to prompt the user for new data, throws
    #     an Error Dialog if no station is selected
    def editStation(self):
        try:
            w = 408
            h = 470
            self.stationWindow = Tk()
            self.stationWindow.wm_title("Edit Station")
            nameLabel = ttk.Label(self.stationWindow, text="Name:")
            nameLabel.grid(in_=self.stationWindow, row=0, column=0, pady=10, sticky=E)
            self.nameEntry = ttk.Entry(self.stationWindow, justify='center')
            self.nameEntry.grid(padx=5, row=0, column=1, pady=10)
            self.nameEntry.insert(0, self.name[self.curIndexF])
            u_label = ttk.Label(self.stationWindow, text="U:")
            u_label.grid(in_=self.stationWindow, row=1, column=1, padx=3, pady=3)
            z_label = ttk.Label(self.stationWindow, text="Z:")
            z_label.grid(in_=self.stationWindow, row=1, column=2)
            topPoint = ttk.Label(self.stationWindow, text="Top Point:")
            topPoint.grid(in_=self.stationWindow, row=2, column=0, padx=3, pady=3, sticky=E)
            self.topPointUEntry = ttk.Entry(self.stationWindow, justify='center')
            self.topPointUEntry.grid(padx=5, row=2, column=1, pady=3)
            self.topPointUEntry.insert(0, self.topPointU[self.curIndexF])
            self.topPointZEntry = ttk.Entry(self.stationWindow, justify='center')
            self.topPointZEntry.grid(padx=5, row=2, column=2, pady=3)
            self.topPointZEntry.insert(0, self.topPointZ[self.curIndexF])
            bottomPoint = ttk.Label(self.stationWindow, text="Bottom Point:")
            bottomPoint.grid(in_=self.stationWindow, row=3, column=0, padx=3, pady=3, sticky=E)
            self.bottomPointUEntry = ttk.Entry(self.stationWindow, justify='center')
            self.bottomPointUEntry.grid(padx=5, row=3, column=1, pady=3)
            self.bottomPointUEntry.insert(0, self.bottomPointU[self.curIndexF])
            self.bottomPointZEntry = ttk.Entry(self.stationWindow, justify='center')
            self.bottomPointZEntry.grid(padx=5, row=3, column=2, pady=3)
            self.bottomPointZEntry.insert(0, self.bottomPointZ[self.curIndexF])
            ttk.Separator(self.stationWindow, orient=HORIZONTAL).grid(columnspan=3, sticky=W+E, pady=10)
            rLabel = ttk.Label(self.stationWindow, text="Leading Edge Radius:")
            rLabel.grid(in_=self.stationWindow, row=5, column=0, padx=3, pady=3, sticky=E)
            self.rEntry = ttk.Entry(self.stationWindow, justify='center')
            self.rEntry.grid(padx=5, row=5, column=1, pady=3)
            self.rEntry.insert(0, self.ler[self.curIndexF])
            hteLabel = ttk.Label(self.stationWindow, text="Half Trailing Edge:")
            hteLabel.grid(in_=self.stationWindow, row=6, column=0, padx=3, pady=3, sticky=E)
            self.hteEntry = ttk.Entry(self.stationWindow, justify='center')
            self.hteEntry.grid(padx=5, row=6, column=1, pady=3)
            self.hteEntry.insert(0, self.hte[self.curIndexF])
            buLabel = ttk.Label(self.stationWindow, text="Beta Upper Angle:")
            buLabel.grid(in_=self.stationWindow, row=7, column=0, padx=3, pady=3, sticky=E)
            self.buEntry = ttk.Entry(self.stationWindow, justify='center')
            self.buEntry.grid(padx=5, row=7, column=1, pady=3)
            self.buEntry.insert(0, self.bu[self.curIndexF])
            blLabel = ttk.Label(self.stationWindow, text="Beta Lower Angle:")
            blLabel.grid(in_=self.stationWindow, row=8, column=0, padx=3, pady=3, sticky=E)
            self.blEntry = ttk.Entry(self.stationWindow, justify='center')
            self.blEntry.grid(padx=5, row=8, column=1, pady=3)
            self.blEntry.insert(0, self.bl[self.curIndexF])
            ugLabel = ttk.Label(self.stationWindow, text="Upper Gamma:")
            ugLabel.grid(in_=self.stationWindow, row=9, column=0, padx=3, pady=3, sticky=E)
            self.ugEntry = ttk.Entry(self.stationWindow, justify='center')
            self.ugEntry.grid(padx=5, row=9, column=1, pady=3)
            self.ugEntry.insert(0, self.ug[self.curIndexF])
            lgLabel = ttk.Label(self.stationWindow, text="Lower Gamma:")
            lgLabel.grid(in_=self.stationWindow, row=10, column=0, padx=3, pady=3, sticky=E)
            self.lgEntry = ttk.Entry(self.stationWindow, justify='center')
            self.lgEntry.grid(padx=5, row=10, column=1, pady=3)
            self.lgEntry.insert(0, self.lg[self.curIndexF])
            ttk.Separator(self.stationWindow, orient=HORIZONTAL).grid(columnspan=3, sticky=W+E, pady=10)
            sparXLabel = ttk.Label(self.stationWindow, text="Spar Backbone X")
            sparXLabel.grid(in_=self.stationWindow, row=12, column=0, padx=20, pady=3, sticky=W+E)
            sparYLabel = ttk.Label(self.stationWindow, text="Spar Backbone Y")
            sparYLabel.grid(in_=self.stationWindow, row=12, column=1, padx=20, pady=3, sticky=W+E)
            sparZLabel = ttk.Label(self.stationWindow, text="Spar Backbone Z")
            sparZLabel.grid(in_=self.stationWindow, row=12, column=2, padx=20, pady=3, sticky=W+E)
            self.sparXEntry = ttk.Entry(self.stationWindow, justify='center')
            self.sparXEntry.grid(padx=5, row=13, column=0, pady=3)
            self.sparXEntry.insert(0, self.sparX[self.curIndexF])
            self.sparYEntry = ttk.Entry(self.stationWindow, justify='center')
            self.sparYEntry.grid(padx=5, row=13, column=1, pady=3)
            self.sparYEntry.insert(0, self.sparY[self.curIndexF])
            self.sparZEntry = ttk.Entry(self.stationWindow, justify='center')
            self.sparZEntry.grid(padx=5, row=13, column=2, pady=3)
            self.sparZEntry.insert(0, self.sparZ[self.curIndexF])
            scaleLabel = ttk.Label(self.stationWindow, text="Scale:")
            scaleLabel.grid(in_=self.stationWindow, row=14, column=0, padx=20, pady=3, sticky=E)
            self.scaleEntry = ttk.Entry(self.stationWindow, justify='center')
            self.scaleEntry.grid(padx=5, row=14, column=1, pady=3)
            self.scaleEntry.insert(0, self.scale[self.curIndexF])
            add = ttk.Button(self.stationWindow, text="OK", command=lambda: self.editStationInputs())
            add.grid(row=15, column=1, sticky=W+E, padx=10, pady=10)
            cancel = ttk.Button(self.stationWindow, text="Cancel", command=lambda: self.cancelF())
            cancel.grid(row=15, column=2, sticky=W+E, padx=10, pady=10)
            ws = self.stationWindow.winfo_screenwidth()
            hs = self.stationWindow.winfo_screenheight()
            x = (ws - w) / 2
            y = (hs - h) / 2
            self.stationWindow.geometry('%dx%d+%d+%d' % (w, h, x, y))
        except:
            self.stationWindow.destroy()
            tkinter.messagebox.showwarning("Error", "Select a station to edit.")

    #   editStationInputs
    #   - Called when the "OK" button is pressed, replaces the selected station with the new data, throws an Error
    #     Dialog if the input values are not acceptable
    def editStationInputs(self):
        if self.nameEntry.get():
            try:
                #Remove current entry
                self.name.pop(self.curIndexF)
                self.topPointU.pop(self.curIndexF)
                self.topPointZ.pop(self.curIndexF)
                self.bottomPointU.pop(self.curIndexF)
                self.bottomPointZ.pop(self.curIndexF)
                self.ler.pop(self.curIndexF)
                self.hte.pop(self.curIndexF)
                self.bu.pop(self.curIndexF)
                self.bl.pop(self.curIndexF)
                self.ug.pop(self.curIndexF)
                self.lg.pop(self.curIndexF)
                self.sparX.pop(self.curIndexF)
                self.sparY.pop(self.curIndexF)
                self.sparZ.pop(self.curIndexF)
                self.scale.pop(self.curIndexF)
                self.listboxF.delete(self.curIndexF)
                #Insert new data into old location
                self.name.insert(self.curIndexF, self.nameEntry.get())
                self.topPointU.insert(self.curIndexF, self.topPointUEntry.get())
                self.topPointZ.insert(self.curIndexF, self.topPointZEntry.get())
                self.bottomPointU.insert(self.curIndexF, self.bottomPointUEntry.get())
                self.bottomPointZ.insert(self.curIndexF, self.bottomPointZEntry.get())
                self.ler.insert(self.curIndexF, self.rEntry.get())
                self.hte.insert(self.curIndexF, self.hteEntry.get())
                self.bu.insert(self.curIndexF, self.buEntry.get())
                self.bl.insert(self.curIndexF, self.blEntry.get())
                self.ug.insert(self.curIndexF, self.ugEntry.get())
                self.lg.insert(self.curIndexF, self.lgEntry.get())
                self.sparX.insert(self.curIndexF, self.sparXEntry.get())
                self.sparY.insert(self.curIndexF, self.sparYEntry.get())
                self.sparZ.insert(self.curIndexF, self.sparZEntry.get())
                self.scale.insert(self.curIndexF, self.scaleEntry.get())
                self.listboxF.insert(self.curIndexF, self.nameEntry.get())
            except ValueError:
                tkinter.messagebox.showerror("Error", "Entries must consist of numerical values and must not be blank.")
        else:
            tkinter.messagebox.showerror("Error", "Enter a name.")
        self.stationWindow.destroy()

    #   addListPoint
    #   - Creates a new window to prompt the user for a new point (Parametric Cubic Spline)
    def addListPoint(self):
        w = 275
        h = 100
        self.pointWindow = Tk()
        self.pointWindow.wm_title("Add Point")
        u_label = ttk.Label(self.pointWindow, text="U:")
        u_label.grid(in_=self.pointWindow, row=0, column=0, padx=3, pady=3)
        self.u_entry = ttk.Entry(self.pointWindow, justify='center')
        self.u_entry.grid(padx=5, row=1, column=0, pady=3)
        z_label = ttk.Label(self.pointWindow, text="Z:")
        z_label.grid(in_=self.pointWindow, row=0, column=1)
        self.z_entry = ttk.Entry(self.pointWindow, justify='center')
        self.z_entry.grid(padx=5, row=1, column=1)
        add = ttk.Button(self.pointWindow, text="Add", command=lambda: self.add())
        add.grid(row=2, column=0, sticky=W+E, padx=10, pady=10)
        cancel = ttk.Button(self.pointWindow, text="Cancel", command=lambda: self.cancel())
        cancel.grid(row=2, column=1, sticky=W+E, padx=10, pady=10)
        ws = self.pointWindow.winfo_screenwidth()
        hs = self.pointWindow.winfo_screenheight()
        x = (ws - w) / 2
        y = (hs - h) / 2
        self.pointWindow.geometry('%dx%d+%d+%d' % (w, h, x, y))

    #   add
    #   - Called when the "Add" button is pressed, takes the input values from the Dialog Box and inserts them into the
    #     listbox, which is used to display points in a scrollable list area, throws an Error Dialog if input values
    #     are not acceptable
    def add(self):
        a = self.u_entry.get()
        b = self.z_entry.get()
        try:
            float(a)
            float(b)
            self.listbox.insert(END, ' ' + self.u_entry.get() + ", " + self.z_entry.get())
        except ValueError:
            tkinter.messagebox.showerror("Error", "Entries must consist of numerical values and must not be blank.")
        self.pointWindow.destroy()

    #   cancel
    #   - Destroys the window for adding new points to the listbox
    def cancel(self):
        self.pointWindow.destroy()

    #   cancelF
    #   - Destroys the station window for adding and editing stations for a 3D Parametric Fourier
    def cancelF(self):
        self.stationWindow.destroy()

    #   deleteListPoint
    #   - Called when the "Delete Point" button is pressed, removes the currently selected point from the point listbox
    def deleteListPoint(self):
        try:
            self.listbox.delete(self.listbox.curselection())
        except:
            tkinter.messagebox.showwarning("Warning", "Must select to delete!")

    #   setCurrent
    #   - Sets the current index value for points to the one selected in the listbox
    def setCurrent(self, event):
        self.curIndex = self.listbox.nearest(event.y)

    #   setCurrentF
    #   - Sets the current index value for 3D Parametric Fourier stations to the one selected in the listbox
    def setCurrentF(self, event):
        self.curIndexF = self.listboxF.nearest(event.y)

    #   shiftSelection
    #   - Called when an event occurs (mouse left click and drag) on the listbox, this method allows for the mouse to
    #     move a listbox entry up or down on the listbox
    def shiftSelection(self, event):
        i = self.listbox.nearest(event.y)
        if i < self.curIndex:
            x = self.listbox.get(i)
            self.listbox.delete(i)
            self.listbox.insert(i+1, x)
            self.listboxcurIndex = i
        elif i > self.curIndex:
            x = self.listbox.get(i)
            self.listbox.delete(i)
            self.listbox.insert(i-1, x)
            self.curIndex = i

    #   newFile
    #   - Creates a "new file", clearing all the current entries
    #   - Not applicable for all geometric methods
    def newFile(self):
        if tkinter.messagebox.askyesno("New File?", "Are you sure you want to start a new file?"):
            self.plot.delete("all")
            self.b1_entry_e_u.delete(0,END)
            self.b1_entry_e_z.delete(0,END)
            self.b1_entry_0_u.delete(0,END)
            self.b1_entry_0_z.delete(0,END)
            self.b1_entry_1_u.delete(0,END)
            self.b1_entry_1_z.delete(0,END)
            self.b1_entry_r.delete(0,END)
            self.b1_entry_b0.delete(0,END)
            self.b1_entry_b1.delete(0,END)
            self.b1_entry_g.delete(0,END)
            self.b2_entry_e_u.delete(0,END)
            self.b2_entry_e_z.delete(0,END)
            self.b2_entry_0_u.delete(0,END)
            self.b2_entry_0_z.delete(0,END)
            self.b2_entry_1_u.delete(0,END)
            self.b2_entry_1_z.delete(0,END)
            self.b2_entry_t_u.delete(0,END)
            self.b2_entry_t_z.delete(0,END)
            self.b2_entry_b_u.delete(0,END)
            self.b2_entry_b_z.delete(0,END)
            self.b2_entry_r.delete(0,END)
            self.b2_entry_b0.delete(0,END)
            self.b2_entry_b1.delete(0,END)
            self.b2_entry_g.delete(0,END)
            self.b3_entry_e_u.delete(0,END)
            self.b3_entry_e_z.delete(0,END)
            self.b3_entry_0_u.delete(0,END)
            self.b3_entry_0_z.delete(0,END)
            self.b3_entry_1_u.delete(0,END)
            self.b3_entry_1_z.delete(0,END)
            self.b3_entry_t_u.delete(0,END)
            self.b3_entry_t_z.delete(0,END)
            self.b3_entry_b_u.delete(0,END)
            self.b3_entry_b_z.delete(0,END)
            self.b3_entry_0_r.delete(0,END)
            self.b3_entry_1_r.delete(0,END)
            self.b3_entry_b0.delete(0,END)
            self.b3_entry_b1.delete(0,END)
            self.b3_entry_0_g.delete(0,END)
            self.b3_entry_1_g.delete(0,END)
            self.f_entry_t_u.delete(0,END)
            self.f_entry_t_z.delete(0,END)
            self.f_entry_b_u.delete(0,END)
            self.f_entry_b_z.delete(0,END)
            self.f_entry_le_r.delete(0,END)
            self.f_entry_hte.delete(0,END)
            self.f_entry_b0.delete(0,END)
            self.f_entry_b1.delete(0,END)
            self.f_entry_0_g.delete(0,END)
            self.f_entry_1_g.delete(0,END)
            self.listbox.delete(0,END)

    #   openFile
    #   - Creates a dialog box to prompt the user for a file name
    #   - Not applicable for all geometric methods
    def openFile(self):
        ftypes = [('All files', '*')]
        dlg = filedialog.Open(self, filetypes = ftypes)
        fl = dlg.show()
        if fl != '':
            text = self.readFile(fl)

    #   readFile
    #   - Opens a text file, reading its data and inserting it into its appropriate field
    #   - Not applicable for all geometric methods
    def readFile(self, filename):
        try:
            f = open(filename, "r")
            text = f.readlines()
            value = []
            for line in text:
                value.append(line.split())
            newvalue = [item[2] for item in value]
            method = self.method.current()
            if(method == 0):
                self.b1_entry_e_u.delete(0,END)
                self.b1_entry_e_u.insert(0,newvalue[0])
                self.b1_entry_e_z.delete(0,END)
                self.b1_entry_e_z.insert(0,newvalue[1])
                self.b1_entry_0_u.delete(0,END)
                self.b1_entry_0_u.insert(0,newvalue[2])
                self.b1_entry_0_z.delete(0,END)
                self.b1_entry_0_z.insert(0,newvalue[3])
                self.b1_entry_1_u.delete(0,END)
                self.b1_entry_1_u.insert(0,newvalue[4])
                self.b1_entry_1_z.delete(0,END)
                self.b1_entry_1_z.insert(0,newvalue[5])
                self.b1_entry_r.delete(0,END)
                self.b1_entry_r.insert(0,newvalue[6])
                self.b1_entry_b0.delete(0,END)
                self.b1_entry_b0.insert(0,newvalue[7])
                self.b1_entry_b1.delete(0,END)
                self.b1_entry_b1.insert(0,newvalue[8])
                self.b1_entry_g.delete(0,END)
                self.b1_entry_g.insert(0,newvalue[9])
            elif(method == 1):
                self.b2_entry_e_u.delete(0,END)
                self.b2_entry_e_u.insert(0,newvalue[0])
                self.b2_entry_e_z.delete(0,END)
                self.b2_entry_e_z.insert(0,newvalue[1])
                self.b2_entry_0_u.delete(0,END)
                self.b2_entry_0_u.insert(0,newvalue[2])
                self.b2_entry_0_z.delete(0,END)
                self.b2_entry_0_z.insert(0,newvalue[3])
                self.b2_entry_1_u.delete(0,END)
                self.b2_entry_1_u.insert(0,newvalue[4])
                self.b2_entry_1_z.delete(0,END)
                self.b2_entry_1_z.insert(0,newvalue[5])
                self.b2_entry_t_u.delete(0,END)
                self.b2_entry_t_u.insert(0,newvalue[6])
                self.b2_entry_t_z.delete(0,END)
                self.b2_entry_t_z.insert(0,newvalue[7])
                self.b2_entry_b_u.delete(0,END)
                self.b2_entry_b_u.insert(0,newvalue[8])
                self.b2_entry_b_z.delete(0,END)
                self.b2_entry_b_z.insert(0,newvalue[9])
                self.b2_entry_r.delete(0,END)
                self.b2_entry_r.insert(0,newvalue[10])
                self.b2_entry_b0.delete(0,END)
                self.b2_entry_b0.insert(0,newvalue[11])
                self.b2_entry_b1.delete(0,END)
                self.b2_entry_b1.insert(0,newvalue[12])
                self.b2_entry_g.delete(0,END)
                self.b2_entry_g.insert(0,newvalue[13])
            elif(method == 2):
                self.b3_entry_e_u.delete(0,END)
                self.b3_entry_e_u.insert(0,newvalue[0])
                self.b3_entry_e_z.delete(0,END)
                self.b3_entry_e_z.insert(0,newvalue[1])
                self.b3_entry_0_u.delete(0,END)
                self.b3_entry_0_u.insert(0,newvalue[2])
                self.b3_entry_0_z.delete(0,END)
                self.b3_entry_0_z.insert(0,newvalue[3])
                self.b3_entry_1_u.delete(0,END)
                self.b3_entry_1_u.insert(0,newvalue[4])
                self.b3_entry_1_z.delete(0,END)
                self.b3_entry_1_z.insert(0,newvalue[5])
                self.b3_entry_t_u.delete(0,END)
                self.b3_entry_t_u.insert(0,newvalue[6])
                self.b3_entry_t_z.delete(0,END)
                self.b3_entry_t_z.insert(0,newvalue[7])
                self.b3_entry_b_u.delete(0,END)
                self.b3_entry_b_u.insert(0,newvalue[8])
                self.b3_entry_b_z.delete(0,END)
                self.b3_entry_b_z.insert(0,newvalue[9])
                self.b3_entry_0_r.delete(0,END)
                self.b3_entry_0_r.insert(0,newvalue[10])
                self.b3_entry_1_r.delete(0,END)
                self.b3_entry_1_r.insert(0,newvalue[11])
                self.b3_entry_b0.delete(0,END)
                self.b3_entry_b0.insert(0,newvalue[12])
                self.b3_entry_b1.delete(0,END)
                self.b3_entry_b1.insert(0,newvalue[13])
                self.b3_entry_0_g.delete(0,END)
                self.b3_entry_0_g.insert(0,newvalue[14])
                self.b3_entry_1_g.delete(0,END)
                self.b3_entry_1_g.insert(0,newvalue[15])
            elif(method == 3):
                tkinter.messagebox.showinfo("Error", "Sorry, open file is not supported for parametric cubic spline.")
            elif(method == 4):
                self.f_entry_t_u.delete(0,END)
                self.f_entry_t_u.insert(0,newvalue[0])
                self.f_entry_t_z.delete(0,END)
                self.f_entry_t_z.insert(0,newvalue[1])
                self.f_entry_b_u.delete(0,END)
                self.f_entry_b_u.insert(0,newvalue[2])
                self.f_entry_b_z.delete(0,END)
                self.f_entry_b_z.insert(0,newvalue[3])
                self.f_entry_le_r.delete(0,END)
                self.f_entry_le_r.insert(0,newvalue[4])
                self.f_entry_hte.delete(0,END)
                self.f_entry_hte.insert(0,newvalue[5])
                self.f_entry_b0.delete(0,END)
                self.f_entry_b0.insert(0,newvalue[6])
                self.f_entry_b1.delete(0,END)
                self.f_entry_b1.insert(0,newvalue[7])
                self.f_entry_0_g.delete(0,END)
                self.f_entry_0_g.insert(0,newvalue[8])
                self.f_entry_1_g.delete(0,END)
                self.f_entry_1_g.insert(0,newvalue[9])
            elif(method == 5):
                tkinter.messagebox.showinfo("Error", "Sorry, open file is not supported for 3D parametric fourier.")
        except:
            tkinter.messagebox.showinfo("Error", "Error loading file.")

    #   saveFileAs
    #   - Opens a file dialog to prompt user for the file name, then writes the appropriate data to a text file
    #   - Not applicable for all geometric methods
    def saveFileAs(self):
        method = self.method.current()
        if(method == 0):
            self.f = filedialog.asksaveasfile(mode='w', defaultextension=".txt")
            self.f.write("leading_edge_u = " + self.b1_entry_e_u.get())
            self.f.write("\nleading_edge_z = " + self.b1_entry_e_z.get())
            self.f.write("\nupper_trailing_edge_u = " + self.b1_entry_0_u.get())
            self.f.write("\nupper_trailing_edge_z = " + self.b1_entry_0_z.get())
            self.f.write("\nlower_trailing_edge_u = " + self.b1_entry_1_u.get())
            self.f.write("\nlower_trailing_edge_z = " + self.b1_entry_1_z.get())
            self.f.write("\nradius = " + self.b1_entry_r.get())
            self.f.write("\nbeta_upper_angle = " + self.b1_entry_b0.get())
            self.f.write("\nbeta_lower_angle = " + self.b1_entry_b1.get())
            self.f.write("\ngamma = " + self.b1_entry_g.get())
            self.f.close()
        elif(method == 1):
            self.f = filedialog.asksaveasfile(mode='w', defaultextension=".txt")
            self.f.write("leading_edge_u = " + self.b2_entry_e_u.get())
            self.f.write("\nleading_edge_z = " + self.b2_entry_e_z.get())
            self.f.write("\nupper_trailing_edge_u = " + self.b2_entry_0_u.get())
            self.f.write("\nupper_trailing_edge_z = " + self.b2_entry_0_z.get())
            self.f.write("\nlower_trailing_edge_u = " + self.b2_entry_1_u.get())
            self.f.write("\nlower_trailing_edge_z = " + self.b2_entry_1_z.get())
            self.f.write("\ntop_point_u = " + self.b2_entry_t_u.get())
            self.f.write("\ntop_point_z = " + self.b2_entry_t_z.get())
            self.f.write("\nbottom_point_u = " + self.b2_entry_b_u.get())
            self.f.write("\nbottom_point_z = " + self.b2_entry_b_z.get())
            self.f.write("\nradius = " + self.b2_entry_r.get())
            self.f.write("\nbeta_upper_angle = " + self.b2_entry_b0.get())
            self.f.write("\nbeta_lower_angle = " + self.b2_entry_b1.get())
            self.f.write("\ngamma = " + self.b2_entry_g.get())
            self.f.close()
        elif(method == 2):
            self.f = filedialog.asksaveasfile(mode='w', defaultextension=".txt")
            self.f.write("leading_edge_u = " + self.b3_entry_e_u.get())
            self.f.write("\nleading_edge_z = " + self.b3_entry_e_z.get())
            self.f.write("\nupper_trailing_edge_u = " + self.b3_entry_0_u.get())
            self.f.write("\nupper_trailing_edge_z = " + self.b3_entry_0_z.get())
            self.f.write("\nlower_trailing_edge_u = " + self.b3_entry_1_u.get())
            self.f.write("\nlower_trailing_edge_z = " + self.b3_entry_1_z.get())
            self.f.write("\ntop_point_u = " + self.b3_entry_t_u.get())
            self.f.write("\ntop_point_z = " + self.b3_entry_t_z.get())
            self.f.write("\nbottom_point_u = " + self.b3_entry_b_u.get())
            self.f.write("\nbottom_point_z = " + self.b3_entry_b_z.get())
            self.f.write("\nupper_radius = " + self.b3_entry_0_r.get())
            self.f.write("\nlower_radius = " + self.b3_entry_1_r.get())
            self.f.write("\nbeta_upper_angle = " + self.b3_entry_b0.get())
            self.f.write("\nbeta_lower_angle = " + self.b3_entry_b1.get())
            self.f.write("\nupper_gamma = " + self.b3_entry_0_g.get())
            self.f.write("\nlower_gamma = " + self.b3_entry_1_g.get())
            self.f.close()
        elif(method == 3):
            tkinter.messagebox.showinfo("Error", "Sorry, save is not supported for parametric cubic spline.")
        elif(method == 4):
            self.f = filedialog.asksaveasfile(mode='w', defaultextension=".txt")
            self.f.write("\ntop_point_u = " + self.f_entry_t_u.get())
            self.f.write("\ntop_point_z = " +self.f_entry_t_z.get())
            self.f.write("\nbottom_point_u = " + self.f_entry_b_u.get())
            self.f.write("\nbottom_point_z = " + self.f_entry_b_z.get())
            self.f.write("\nleading_edge_radius = " + self.f_entry_le_r.get())
            self.f.write("\nhalf_trailing_edge = " + self.f_entry_hte.get())
            self.f.write("\nbeta_upper_angle = " + self.f_entry_b0.get())
            self.f.write("\nbeta_lower_angle = " + self.f_entry_b1.get())
            self.f.write("\nupper_gamma = " + self.f_entry_0_g.get())
            self.f.write("\nlower_gamma = " + self.f_entry_1_g.get())
            self.f.close()
        elif(method == 5):
            tkinter.messagebox.showinfo("Error", "Sorry, save is not supported for 3D parametric fourier.")

    #   saveFile
    #   - Opens a file dialog to prompt user for the file name, then writes the appropriate data to a text file
    #   - Not applicable for all geometric methods
    def saveFile(self):
        method = self.method.current()
        if(method == 0):
            newfile = open(self.f.name, "w")
            newfile.write("leading_edge_u = " + self.b1_entry_e_u.get())
            newfile.write("\nleading_edge_z = " + self.b1_entry_e_z.get())
            newfile.write("\nupper_trailing_edge_u = " + self.b1_entry_0_u.get())
            newfile.write("\nupper_trailing_edge_z = " + self.b1_entry_0_z.get())
            newfile.write("\nlower_trailing_edge_u = " + self.b1_entry_1_u.get())
            newfile.write("\nlower_trailing_edge_z = " + self.b1_entry_1_z.get())
            newfile.write("\nradius = " + self.b1_entry_r.get())
            newfile.write("\nbeta_upper_angle = " + self.b1_entry_b0.get())
            newfile.write("\nbeta_lower_angle = " + self.b1_entry_b1.get())
            newfile.write("\ngamma = " + self.b1_entry_g.get())
            tkinter.messagebox.showinfo("Saved", "Saved successfully.")
            newfile.close()
        elif(method == 1):
            newfile = open(self.f.name, "w")
            newfile.write("leading_edge_u = " + self.b2_entry_e_u.get())
            newfile.write("\nleading_edge_z = " + self.b2_entry_e_z.get())
            newfile.write("\nupper_trailing_edge_u = " + self.b2_entry_0_u.get())
            newfile.write("\nupper_trailing_edge_z = " + self.b2_entry_0_z.get())
            newfile.write("\nlower_trailing_edge_u = " + self.b2_entry_1_u.get())
            newfile.write("\nlower_trailing_edge_z = " + self.b2_entry_1_z.get())
            newfile.write("\ntop_point_u = " + self.b2_entry_t_u.get())
            newfile.write("\ntop_point_z = " + self.b2_entry_t_z.get())
            newfile.write("\nbottom_point_u = " + self.b2_entry_b_u.get())
            newfile.write("\nbottom_point_z = " + self.b2_entry_b_z.get())
            newfile.write("\nradius = " + self.b2_entry_r.get())
            newfile.write("\nbeta_upper_angle = " + self.b2_entry_b0.get())
            newfile.write("\nbeta_lower_angle = " + self.b2_entry_b1.get())
            newfile.write("\ngamma = " + self.b2_entry_g.get())
            tkinter.messagebox.showinfo("Saved", "Saved successfully.")
            newfile.close()
        elif(method == 2):
            newfile = open(self.f.name, "w")
            newfile.write("leading_edge_u = " + self.b3_entry_e_u.get())
            newfile.write("\nleading_edge_z = " + self.b3_entry_e_z.get())
            newfile.write("\nupper_trailing_edge_u = " + self.b3_entry_0_u.get())
            newfile.write("\nupper_trailing_edge_z = " + self.b3_entry_0_z.get())
            newfile.write("\nlower_trailing_edge_u = " + self.b3_entry_1_u.get())
            newfile.write("\nlower_trailing_edge_z = " + self.b3_entry_1_z.get())
            newfile.write("\ntop_point_u = " + self.b3_entry_t_u.get())
            newfile.write("\ntop_point_z = " + self.b3_entry_t_z.get())
            newfile.write("\nbottom_point_u = " + self.b3_entry_b_u.get())
            newfile.write("\nbottom_point_z = " + self.b3_entry_b_z.get())
            newfile.write("\nupper_radius = " + self.b3_entry_0_r.get())
            newfile.write("\nlower_radius = " + self.b3_entry_1_r.get())
            newfile.write("\nbeta_upper_angle = " + self.b3_entry_b0.get())
            newfile.write("\nbeta_lower_angle = " + self.b3_entry_b1.get())
            newfile.write("\nupper_gamma = " + self.b3_entry_0_g.get())
            newfile.write("\nlower_gamma = " + self.b3_entry_1_g.get())
            tkinter.messagebox.showinfo("Saved", "Saved successfully.")
            newfile.close()
        elif(method == 3):
            tkinter.messagebox.showinfo("Error", "Sorry, save is not supported for parametric cubic spline.")
        elif(method == 4):
            newfile = open(self.f.name, "w")
            newfile.write("\ntop_point_u = " + self.f_entry_t_u.get())
            newfile.write("\ntop_point_z = " +self.f_entry_t_z.get())
            newfile.write("\nbottom_point_u = " + self.f_entry_b_u.get())
            newfile.write("\nbottom_point_z = " + self.f_entry_b_z.get())
            newfile.write("\nleading_edge_radius = " + self.f_entry_le_r.get())
            newfile.write("\nhalf_trailing_edge = " + self.f_entry_hte.get())
            newfile.write("\nbeta_upper_angle = " + self.f_entry_b0.get())
            newfile.write("\nbeta_lower_angle = " + self.f_entry_b1.get())
            newfile.write("\nupper_gamma = " + self.f_entry_0_g.get())
            newfile.write("\nlower_gamma = " + self.f_entry_1_g.get())
            tkinter.messagebox.showinfo("Saved", "Saved successfully.")
            newfile.close()
        elif(method == 5):
            tkinter.messagebox.showinfo("Error", "Sorry, save is not supported for 3D parametric fourier.")

    #   export
    #   - Checks if a method has been selected to call exportToBlender
    def export(self):
        if(self.method.get()=='Select a method here.'):
            tkinter.messagebox.showinfo("Error", "Choose a method first.")
        else:
            self.exportToBlender()

    #   plotOrientation
    #   - Changes the orientation of the plot (left or right side of the application)
    def plotOrientation(self):
        if(self.inputsF.pack_info()['side'] == 'right'):
            self.inputsF.pack(side="left", fill="both", expand=True)
        else:
            self.inputsF.pack(side="right", fill="both", expand=True)

    #   scrollbar
    #   - Configures a scrollbar to be used on a frame
    def scrollbar(self, event):
        self.canvas.configure(scrollregion = self.canvas.bbox("all"), width = 375, height = 470)

    #   help
    #   - Creates a new scrollable window with information on each geometric methods
    def help(self):
        w = 397
        h = 475
        newWindow = Tk()
        newWindow.wm_title("Help")
        ws = newWindow.winfo_screenwidth()
        hs = newWindow.winfo_screenheight()
        x = (ws - w) / 2
        y = (hs - h) / 2
        newWindow.geometry('%dx%d+%d+%d' % (w, h, x, y))
        myframe = Frame(newWindow, relief = GROOVE, width = 100, height = 100, bd = 1)
        myframe.place(x = 0, y = 0)
        self.canvas = Canvas(myframe, background = "#ffffff")
        frame = Frame(self.canvas, background = "#ffffff")
        myscrollbar = ttk.Scrollbar(myframe, orient="vertical", command=self.canvas.yview)
        self.canvas.configure(yscrollcommand = myscrollbar.set)
        myscrollbar.pack(side = "right", fill = "y")
        self.canvas.pack(side = "left")
        self.canvas.create_window((0,0), window = frame, anchor = 'nw')
        Label(frame, justify = "center", font = "Helvetica 24 bold underline", background = "#ffffff",
              text = "Help").pack(side = "top", padx = 10, pady= 10)
        Label(frame, justify = "center", background = "#ffffff", fg = "#336699",
              font = "Helvetica 12 bold", text = "\nParametric Polynomial").pack(side = "top", padx = 10, pady= 10)
        Label(frame, justify = "left", background = "#ffffff",
              text="The parametric polynomial allows you to specify values at key"
                    "\npoints in the airfoil such as leading edge radius, afterbody   "
                    "\nangles, and top and bottom point maximums. There are 3   "
                    "\ndifferent boundary conditions. Selecting different boundary   "
                    "\nconditions will allow you more and different key point options.  "
                    "\nEnter your values and click 'Apply Settings' to"
                    " generate the plot. ").pack(side = "top", padx = 10, pady= 10)
        Label(frame, justify = "center", background = "#ffffff", fg = "#336699",
              font = "Helvetica 12 bold", text = "\nParametric Cubic Spline").pack(side = "top", padx = 10, pady= 10)
        Label(frame, justify = "left", background = "#ffffff",
              text="The parametric cubic spline allows you to specify a number of  "
                    "\npoints around the airfoil. There are already default points "
                    "\nprogrammed in for you to use. First you need to choose the "
                    "\nshape of the left and right end constraints of the airfoil by"
                    "\nselecting from the drop-down menu. You can add more points "
                    "\nby clicking the 'Add Point' button. You can delete points by "
                    "\nhighlighting the set of points you want to delete and clicking "
                    "\nthe 'Delete Point' button. Once you have the points you want to "
                    "\nuse, click 'Apply Settings' to generate the plot.").pack(side = "top", padx = 10, pady= 10)
        Label(frame, justify = "center", background = "#ffffff", fg = "#336699",
              font = "Helvetica 12 bold", text = "\nParametric Fourier").pack(side = "top", padx = 10, pady= 10)
        Label(frame, justify = "left", background = "#ffffff",
              text="The 2D parametric fourier allows you to define 8 values: "
                    "\n top point, bottom point, leading edge radius, half trailing edge,"
                    "\nbeta upper angle, beta lower angle, upper gamma, and lower "
                    "\ngamma to fine tune the upper and lower halves of the airfoil. "
                    "\nEnter your values and click ‘Apply Settings’ to generate the plot."
                    "\n\nThe 3D parametric Fourier allows you to define the values for "
                    "\nmultiple airfoils (stations), across the span of a wing. An object "
                    "\nis then generated with these airfoils connected. Note that the "
                    "\nairfoil is connected to the next airfoil as it goes down the list, so "
                    "\nthe order in which you add the stations to the list will determine"
                    "\nthe order in which they are generated and connected. There is a "
                    "\nset of preset stations as an example. You can add stations by "
                    "\n clicking ‘add station’, edit stations by clicking ‘edit station’, and "
                    "\ndelete stations by selecting a station and clicking ‘delete station'. "
                    " \nClick ‘Plot Selected Airfoil’ to plot the "
                    "selected airfoil.").pack(side = "top", padx = 10, pady= 10)
        Label(frame, justify = "center", background = "#ffffff", fg = "#336699",
              font = "Helvetica 12 bold", text = "\nOpening/Saving .txt Files").pack(side = "top", padx = 10, pady= 10)
        Label(frame, justify = "left", background = "#ffffff",
              text="Opening/saving .txt files is only supported for the parametric  "
                    "\npolynomial and the 2D parametric fourier. Download the 4 "
                    "\n.txt files from our website."
                    "\n\nTo open:"
                    "\n1.) Select the generation method you want to use."
                    "\n2.) Go to ‘File’."
                    "\n3.) Select ‘Open’."
                    "\n4.) Select the corresponding .txt file from wherever you have it "
                    "\nsaved and click ‘Open’. The values from the file should be "
                    "\nimported."
                    "\n5.) Click ‘Apply Settings’ to generate the plot."
                    "\n\nTo save any points you have entered:"
                    "\n1.) Go to ‘File’."
                    "\n2.) Select ‘Save As’."
                    "\n3.) Enter a name and click ‘Save’."
                    " \n\nOnce you have created your .txt file, you can continue working."
                    "\nIf you want to save again, go to ‘File’ "
                    "and select ‘Save’ this time.").pack(side = "top", padx = 10, pady= 10)
        Label(frame, justify = "center", background = "#ffffff", fg = "#336699",
              font = "Helvetica 12 bold", text = "\nConnecting/Exporting"
                                                 " to Blender").pack(side = "top", padx = 10, pady= 10)
        Label(frame, justify = "left", background = "#ffffff",
              text="Once you have your airfoil generated with your preferred  "
                "\ngeneration method and you want to export to Blender, follow "
                "\nthese steps before hitting ‘Export to Blender’:"
                "\n\n1.) Download the ‘testserver.py’ file from our website. "
                "\n2.) Open up Blender"
                "\n3.) Click on the 'Choose Screen Layout' button and select"
                "\n‘Scripting’."
                "\n4.) Click ‘New’ to create a new text data block."
                "\n5.) Paste the ‘testserver.py’ code into the space. "
                "\n6.) Click ‘Run Script’. "
                "\nNote: If you are using a small computer screen, you may "
                "\nhave to drag the scripting window to see the ‘Run Script’"
                "\nbutton. "
                "\n7.) Click on the ‘Choose Screen Layout’ button again and select "
                " \n‘Default’. You should now see ‘Aircraft Generator’ in the left "
                "\nmodule. It should say ‘Status: Not Linked’."
                "\n8.) Click ‘Link to Aircraft Generator’. It should change to"
                "\n‘Status: Linked’. "
                "\n9.) Come back to this Wing Generator application and click"
                "\n‘Export to Blender’. "
                "\n10.) Go back to Blender. You should "
                "now see the generated model.").pack(side = "top", padx = 10, pady= 10)
        Label(frame, justify = "center", background = "#ffffff", fg = "#336699",
              text = "\nFor more detailed help, refer to our user manual.").pack(side = "top", padx = 10, pady= 10)
        frame.bind("<Configure>", self.scrollbar)

    #   about
    #   - Creates a new window with general information on the project
    def about(self):
        w = 300
        h = 150
        newWindow = Tk()
        newWindow.wm_title("About")
        l = Label(newWindow, text="CSULB Northrop Grumman Student Design Project\n"
                                  "Wing Generator v. 1.0 \nwww.csulb-ngcproject.me\nSpring 2015")
        l.pack(side = "left", fill = BOTH, padx = 10)
        ws = newWindow.winfo_screenwidth()
        hs = newWindow.winfo_screenheight()
        x = (ws - w) / 2
        y = (hs - h) / 2
        newWindow.geometry('%dx%d+%d+%d' % (w, h, x, y))

    #   newsettings
    #   - Checks the current value of the method combobox, changing the panel to appropriately
    def newsettings(self, event):
        value = self.method.current()
        self.resizeWindow()
        if(value == 0):
            self.settingsLF0.grid_forget()
            self.settingsLF2.grid_forget()
            self.settingsLF3.grid_forget()
            self.settingsLF4.grid_forget()
            self.settingsLF5.grid_forget()
            self.settingsLF6.grid_forget()
            self.settingsLF1.grid(in_=self.inputsF, column=0, row=1, sticky=W+E)
            self.settingsLF1.grid_columnconfigure(0, weight=1)
            self.applyB.configure(text="Apply Settings")
        elif(value == 1):
            self.settingsLF0.grid_forget()
            self.settingsLF1.grid_forget()
            self.settingsLF3.grid_forget()
            self.settingsLF4.grid_forget()
            self.settingsLF5.grid_forget()
            self.settingsLF6.grid_forget()
            self.settingsLF2.grid(in_=self.inputsF, column=0, row=1, sticky=W+E)
            self.settingsLF2.grid_columnconfigure(0, weight=1)
            self.applyB.configure(text="Apply Settings")
        elif(value == 2):
            self.settingsLF0.grid_forget()
            self.settingsLF1.grid_forget()
            self.settingsLF2.grid_forget()
            self.settingsLF4.grid_forget()
            self.settingsLF5.grid_forget()
            self.settingsLF6.grid_forget()
            self.settingsLF3.grid(in_=self.inputsF, column=0, row=1, sticky=W+E)
            self.settingsLF3.grid_columnconfigure(0, weight=1)
            self.applyB.configure(text="Apply Settings")
        elif(value == 3):
            self.settingsLF0.grid_forget()
            self.settingsLF1.grid_forget()
            self.settingsLF2.grid_forget()
            self.settingsLF3.grid_forget()
            self.settingsLF5.grid_forget()
            self.settingsLF6.grid_forget()
            self.settingsLF4.grid(in_=self.inputsF, column=0, row=2, sticky=W+E)
            self.settingsLF4.grid_columnconfigure(0, weight=1)
            self.applyB.configure(text="Apply Settings")
        elif(value == 4):
            self.settingsLF0.grid_forget()
            self.settingsLF1.grid_forget()
            self.settingsLF2.grid_forget()
            self.settingsLF3.grid_forget()
            self.settingsLF4.grid_forget()
            self.settingsLF6.grid_forget()
            self.settingsLF5.grid(in_=self.inputsF, column=0, row=2, sticky=W+E)
            self.settingsLF5.grid_columnconfigure(0, weight=1)
            self.applyB.configure(text="Apply Settings")
        elif(value == 5):
            self.settingsLF0.grid_forget()
            self.settingsLF1.grid_forget()
            self.settingsLF2.grid_forget()
            self.settingsLF3.grid_forget()
            self.settingsLF4.grid_forget()
            self.settingsLF5.grid_forget()
            self.settingsLF6.grid(in_=self.inputsF, column=0, row=2, sticky=W+E)
            self.settingsLF6.grid_columnconfigure(0, weight=1)
            self.applyB.configure(text="Plot Selected Station")

    #   apply
    #   - Checks the current value of the method combobox, calling the appropriate geometric generation method and
    #     drawing the results, throws an Error Dialog if the input values are not acceptable
    def apply(self):
        if(self.method.current()=='Select a method here.'):
            tkinter.messagebox.showerror("Error", "Choose a method first.")
        elif(self.method.get()=='2D - Parametric Polynomial - Boundary Condition 1'):
            try:
                X =pp.boundaryOne(float(self.b1_entry_e_u.get()), float(self.b1_entry_e_z.get()),
                float(self.b1_entry_0_u.get()), float(self.b1_entry_0_z.get()), float(self.b1_entry_1_u.get()),
                float(self.b1_entry_1_z.get()), float(self.b1_entry_r.get()), float(self.b1_entry_b0.get()),
                float(self.b1_entry_b1.get()), float(self.b1_entry_g.get()))
                self.draw(X)
            except ValueError:
                tkinter.messagebox.showerror("Error", "Entries must consist of numerical values and must not be blank.")
        elif(self.method.get()=='2D - Parametric Polynomial - Boundary Condition 2'):
            try:
                X =pp.boundaryTwo(float(self.b2_entry_e_u.get()), float(self.b2_entry_e_z.get()),
                float(self.b2_entry_0_u.get()), float(self.b2_entry_0_z.get()), float(self.b2_entry_1_u.get()),
                float(self.b2_entry_1_z.get()), float(self.b2_entry_r.get()), float(self.b2_entry_b0.get()),
                float(self.b2_entry_b1.get()), float(self.b2_entry_g.get()), float(self.b2_entry_t_u.get()),
                float(self.b2_entry_t_z.get()), float(self.b2_entry_b_u.get()), float(self.b2_entry_b_z.get()) )
                self.draw(X)
            except ValueError:
                tkinter.messagebox.showerror("Error", "Entries must consist of numerical values and must not be blank.")
        elif(self.method.get()=='2D - Parametric Polynomial - Boundary Condition 3'):
            try:
                X = pp.boundaryThree(float(self.b3_entry_e_u.get()), float(self.b3_entry_e_z.get()),
                float(self.b3_entry_0_u.get()), float(self.b3_entry_0_z.get()), float(self.b3_entry_1_u.get()),
                float(self.b3_entry_1_z.get()), float(self.b3_entry_t_u.get()), float(self.b3_entry_t_z.get()),
                float(self.b3_entry_b_u.get()), float(self.b3_entry_b_z.get()), float(self.b3_entry_0_r.get()),
                float(self.b3_entry_1_r.get()), float(self.b3_entry_b0.get()), float(self.b3_entry_b1.get()),
                float(self.b3_entry_0_g.get()), float(self.b3_entry_1_g.get()))
                self.draw(X)
            except ValueError:
                tkinter.messagebox.showerror("Error", "Entries must consist of numerical values and must not be blank.")
        elif(self.method.get()=='2D - Parametric Cubic Spline'):
            if (self.leftConstraint.current() == 0 or self.rightConstraint.current() == 0):
                tkinter.messagebox.showerror("Error", "Select constraints.")
            else:
                try:
                    points = []
                    tau = ""
                    zeta = ""
                    points = self.listbox.get(0,END)
                    for i in range(0, len(points)):
                        temp = points[i].split(',')
                        if(i < len(points)-1):
                            tau = tau + (temp[0]) + ','
                            zeta = zeta + (temp[1]) + ','
                        else:
                            tau = tau + (temp[0])
                            zeta = zeta + (temp[1])
                    X = pcs.parametricCubicSpline(tau, zeta, self.leftConstraint.current(),
                                                  self.rightConstraint.current())
                    self.draw(X)
                except:
                    tkinter.messagebox.showerror("Error", "Add points.")
        elif(self.method.get()=='2D - Parametric Fourier'):
            try:
                X = pf.parametricFourier(float(self.f_entry_0_g.get()), float(self.f_entry_1_g.get()),
                float(self.f_entry_le_r.get()), float(self.f_entry_t_u.get()), float(self.f_entry_t_z.get()),
                float(self.f_entry_b_u.get()), float(self.f_entry_b_z.get()), float(self.f_entry_b0.get()),
                float(self.f_entry_b1.get()), float(self.f_entry_hte.get()))
                self.draw(X)
            except ValueError:
                tkinter.messagebox.showerror("Error", "Entries must consist of numerical values and must not be blank.")
        elif(self.method.get()=='3D - Parametric Fourier'):
            try:
                X = pf.parametricFourier(float(self.ug[self.curIndexF]), float(self.lg[self.curIndexF]),
                float(self.ler[self.curIndexF]), float(self.topPointU[self.curIndexF]),
                float(self.topPointZ[self.curIndexF]),
                float(self.bottomPointU[self.curIndexF]), float(self.bottomPointZ[self.curIndexF]),
                float(self.bu[self.curIndexF]),
                float(self.bl[self.curIndexF]), float(self.hte[self.curIndexF]))
                self.draw(X)
            except:
                tkinter.messagebox.showerror("Error", "Select a station to plot.")

    #   draw
    #   - Checks the current value of the method combobox, doing the appropriate calculations for coordinates for
    #     the corresponding method, coordinates must be changed from cartesian to the graphical window
    def draw(self, X):
        value = self.method.current()
        if(value == 0):
            self.plot.delete("all")
            self.plot.create_rectangle(1, 1, 400, 200)
            previousX = 1-(1-float(self.b1_entry_g.get()))*math.sin(math.pi*0)\
                            +float(self.b1_entry_g.get())*math.sin(3*math.pi*0)
            previousY = float(self.b1_entry_0_z.get())*(1-2*0) + X[0]*0 + X[1]*math.pow(0,2) + X[2]*math.pow(0,3) \
                            + X[3]*math.pow(0,4) + X[4]*math.pow(0,5)
            previousX = 400 * previousX
            previousY = -200 * previousY + 100
            for i in range(1, 41):
                u = i/40
                myCanvasX = 1-(1-float(self.b1_entry_g.get()))*math.sin(math.pi*u)\
                            +float(self.b1_entry_g.get())*math.sin(3*math.pi*u)
                myCanvasY = float(self.b1_entry_0_z.get())*(1-2*u) + X[0]*u + X[1]*math.pow(u,2) + X[2]*math.pow(u,3) \
                            + X[3]*math.pow(u,4) + X[4]*math.pow(u,5)
                #Change from MyCanvas coordinate to Window coordinate
                windowX = 400 * myCanvasX
                windowY = -200 * myCanvasY + 100
                self.plot.create_line(windowX, windowY, previousX, previousY)
                previousX = windowX
                previousY = windowY
        elif(value == 1):
            self.plot.delete("all")
            self.plot.create_rectangle(1, 1, 400, 200)
            previousX = 1-(1-float(self.b2_entry_g.get()))*math.sin(math.pi*0) \
                        + float(self.b2_entry_g.get())*math.sin(3*math.pi*0)
            previousY = float(self.b2_entry_0_z.get())*(1-2*0) + X[0]*0 + X[1]*math.pow(0,2) \
                        + X[2]*math.pow(0,3) + X[3]*math.pow(0,4) + X[4]*math.pow(0,5) + X[5]*math.pow(0,6) \
                        + X[6]*math.pow(0,7)
            previousX = 400 * previousX
            previousY = -200 * previousY + 100
            for i in range(1, 41):
                u = i/40
                myCanvasX = 1-(1-float(self.b2_entry_g.get()))*math.sin(math.pi*u) \
                            + float(self.b2_entry_g.get())*math.sin(3*math.pi*u)
                myCanvasY = float(self.b2_entry_0_z.get())*(1-2*u) + X[0]*u + X[1]*math.pow(u,2) \
                            + X[2]*math.pow(u,3) + X[3]*math.pow(u,4) + X[4]*math.pow(u,5) + X[5]*math.pow(u,6) \
                            + X[6]*math.pow(u,7)
                #Change from MyCanvas coordinate to Window coordinate
                windowX = 400 * myCanvasX
                windowY = -200 * myCanvasY + 100
                self.plot.create_line(windowX, windowY, previousX, previousY)
                previousX = windowX
                previousY = windowY
        elif(value == 2):
            self.plot.delete("all")
            self.plot.create_rectangle(1, 1, 400, 200)
            w = 1
            previousX = 1 - (1 - float(self.b3_entry_0_g.get())) * math.cos(w*math.pi/2) \
                        - float(self.b3_entry_0_g.get()) * math.cos(w*3*math.pi/2)
            previousY = float(X[0,0]*w + X[0,1]*math.pow(w,2) + X[0,2]*math.pow(w,3) + X[0,3]*math.pow(w,4)
                                  + X[0,4]*math.pow(w,5))
            previousX = 400 * previousX
            previousY = -200 * previousY + 100
            for i in range(0, 20):
                u = 0.5*i/19
                w=1-2*u
                myCanvasX = 1 - (1 - float(self.b3_entry_0_g.get())) * math.cos(w*math.pi/2) \
                            - float(self.b3_entry_0_g.get()) * math.cos(w*3*math.pi/2)
                myCanvasY = float(X[0,0]*w + X[0,1]*math.pow(w,2) + X[0,2]*math.pow(w,3) + X[0,3]*math.pow(w,4)
                                  + X[0,4]*math.pow(w,5))
                #Change from MyCanvas coordinate to Window coordinate
                windowX = 400 * myCanvasX
                windowY = -200 * myCanvasY + 100
                self.plot.create_line(windowX, windowY, previousX, previousY)
                previousX = windowX
                previousY = windowY
            for i in range(0, 20):
                u = 0.5+0.5*i/19
                w=2*u-1
                myCanvasX = 1 - (1 - float(self.b3_entry_1_g.get())) * math.cos(w*math.pi/2) \
                            - float(self.b3_entry_1_g.get()) * math.cos(w*3*math.pi/2)
                myCanvasY = float(X[1,0]*w + X[1,1]*math.pow(w,2) + X[1,2]*math.pow(w,3) + X[1,3]*math.pow(w,4)
                                  + X[1,4]*math.pow(w,5))
                #Change from MyCanvas coordinate to Window coordinate
                windowX = 400 * myCanvasX
                windowY = -200 * myCanvasY + 100
                self.plot.create_line(windowX, windowY, previousX, previousY)
                previousX = windowX
                previousY = windowY
        elif(value == 3):
            self.plot.delete("all")
            self.plot.create_rectangle(1, 1, 400, 200)
            previousX = 1-(1-0.05)*math.sin(math.pi*0) \
                        + 0.05*math.sin(3*math.pi*0)
            previousY = X[0]
            previousX = 400 * previousX
            previousY = -200 * previousY + 100
            for i in range(1, 41):
                u = i/40
                myCanvasX = 1-(1-0.05)*math.sin(math.pi*u) \
                            + 0.05*math.sin(3*math.pi*u)
                myCanvasY = X[i]

                #Change from MyCanvas coordinate to Window coordinate
                windowX = 400 * myCanvasX
                windowY = -200 * myCanvasY + 100
                self.plot.create_line(windowX, windowY, previousX, previousY)
                previousX = windowX
                previousY = windowY
        elif(value == 4):
            self.plot.delete("all")
            self.plot.create_rectangle(1, 1, 400, 200)
            n = 8
            gam = pf.gam_(0, float(self.f_entry_0_g.get()), float(self.f_entry_1_g.get()))
            ww = 1 - 2 * 0
            previousX = pf.X_of_W(gam, ww)
            previousY = float(self.f_entry_hte.get()) * (1 - 2 * 0)
            previousX = 400 * previousX
            previousY = -200 * previousY + 100
            for i in range(1, 41):
                u = i/40
                gam = pf.gam_(u, float(self.f_entry_0_g.get()), float(self.f_entry_1_g.get()))
                if(u < 0.5):
                    ww = 1 - 2 * u
                else:
                    ww = 2 * u - 1
                xx = pf.X_of_W(gam, ww)
                zz = float(self.f_entry_hte.get()) * (1 - 2 * u)
                for j in range(0, n):
                    remain = 1
                    zz = zz + X[j] * math.sin(remain * math.pi * (j+1) * u)
                windowX = 400 * xx
                windowY = -200 * zz + 100
                self.plot.create_line(windowX, windowY, previousX, previousY)
                previousX = windowX
                previousY = windowY
        elif(value == 5):
            self.plot.delete("all")
            self.plot.create_rectangle(1, 1, 400, 200)
            n = 8
            gam = pf.gam_(0, float(self.ug[self.curIndexF]), float(self.lg[self.curIndexF]))
            ww = 1 - 2 * 0
            previousX = pf.X_of_W(gam, ww)
            previousY = float(self.hte[self.curIndexF]) * (1 - 2 * 0)
            previousX = 400 * previousX
            previousY = -200 * previousY + 100
            for i in range(1, 41):
                u = i/40
                gam = pf.gam_(u, float(self.ug[self.curIndexF]), float(self.lg[self.curIndexF]))
                if(u < 0.5):
                    ww = 1 - 2 * u
                else:
                    ww = 2 * u - 1
                xx = pf.X_of_W(gam, ww)
                zz = float(self.hte[self.curIndexF]) * (1 - 2 * u)
                for j in range(0, n):
                    remain = 1
                    zz = zz + X[j] * math.sin(remain * math.pi * (j+1) * u)
                windowX = 400 * xx
                windowY = -200 * zz + 100
                self.plot.create_line(windowX, windowY, previousX, previousY)
                previousX = windowX
                previousY = windowY

    #   exportToBlender
    #   - Checks the current value of the method combobox, doing the appropriate calculations and calling the sendData
    #     function
    #   - Note that coordinates to not have to be converted to the window coordinates, as Blender uses Cartesian
    def exportToBlender(self):
        data = ""
        value = self.method.current()
        if(value == 0):
            try:
                X = pp.boundaryOne(float(self.b1_entry_e_u.get()), float(self.b1_entry_e_z.get()),
                    float(self.b1_entry_0_u.get()), float(self.b1_entry_0_z.get()), float(self.b1_entry_1_u.get()),
                    float(self.b1_entry_1_z.get()), float(self.b1_entry_r.get()), float(self.b1_entry_b0.get()),
                    float(self.b1_entry_b1.get()), float(self.b1_entry_g.get()))
                previousX = 1-(1-float(self.b1_entry_g.get()))*math.sin(math.pi*0)\
                                +float(self.b1_entry_g.get())*math.sin(3*math.pi*0)
                previousY = float(self.b1_entry_0_z.get())*(1-2*0) + X[0]*0 + X[1]*math.pow(0,2) + X[2]*math.pow(0,3) \
                                + X[3]*math.pow(0,4) + X[4]*math.pow(0,5)
                data = data + str(previousX) + "," + str(previousY) + ","
                for i in range(1, 41):
                    u = i/40
                    myCanvasX = 1-(1-float(self.b1_entry_g.get()))*math.sin(math.pi*u)\
                                +float(self.b1_entry_g.get())*math.sin(3*math.pi*u)
                    myCanvasY = float(self.b1_entry_0_z.get())*(1-2*u) + X[0]*u \
                                + X[1]*math.pow(u,2) + X[2]*math.pow(u,3) \
                                + X[3]*math.pow(u,4) + X[4]*math.pow(u,5)
                    data = data + str(myCanvasX) + "," + str(myCanvasY) + ","
                data = data + "0" + ","
                self.sendData(data)
            except ValueError:
                tkinter.messagebox.showerror("Error", "Entries must consist of numerical values and must not be blank.")
        elif(value == 1):
            try:
                X = pp.boundaryTwo(float(self.b2_entry_e_u.get()), float(self.b2_entry_e_z.get()),
                    float(self.b2_entry_0_u.get()), float(self.b2_entry_0_z.get()), float(self.b2_entry_1_u.get()),
                    float(self.b2_entry_1_z.get()), float(self.b2_entry_r.get()), float(self.b2_entry_b0.get()),
                    float(self.b2_entry_b1.get()), float(self.b2_entry_g.get()), float(self.b2_entry_t_u.get()),
                    float(self.b2_entry_t_z.get()), float(self.b2_entry_b_u.get()), float(self.b2_entry_b_z.get()) )
                previousX = 1-(1-float(self.b2_entry_g.get()))*math.sin(math.pi*0) \
                            + float(self.b2_entry_g.get())*math.sin(3*math.pi*0)
                previousY = float(self.b2_entry_0_z.get())*(1-2*0) + X[0]*0 + X[1]*math.pow(0,2) \
                            + X[2]*math.pow(0,3) + X[3]*math.pow(0,4) + X[4]*math.pow(0,5) + X[5]*math.pow(0,6) \
                            + X[6]*math.pow(0,7)
                data = data + str(previousX) + "," + str(previousY) + ","
                for i in range(1, 41):
                    u = i/40
                    myCanvasX = 1-(1-float(self.b2_entry_g.get()))*math.sin(math.pi*u) \
                                + float(self.b2_entry_g.get())*math.sin(3*math.pi*u)
                    myCanvasY = float(self.b2_entry_0_z.get())*(1-2*u) + X[0]*u + X[1]*math.pow(u,2) \
                                + X[2]*math.pow(u,3) + X[3]*math.pow(u,4) + X[4]*math.pow(u,5) + X[5]*math.pow(u,6) \
                                + X[6]*math.pow(u,7)
                    data = data + str(myCanvasX) + "," + str(myCanvasY) + ","
                data = data + "0" + ","
                self.sendData(data)
            except ValueError:
                tkinter.messagebox.showerror("Error", "Entries must consist of numerical values and must not be blank.")
        elif(value==2):
            try:
                X = pp.boundaryThree(float(self.b3_entry_e_u.get()), float(self.b3_entry_e_z.get()),
                    float(self.b3_entry_0_u.get()), float(self.b3_entry_0_z.get()), float(self.b3_entry_1_u.get()),
                    float(self.b3_entry_1_z.get()), float(self.b3_entry_t_u.get()), float(self.b3_entry_t_z.get()),
                    float(self.b3_entry_b_u.get()), float(self.b3_entry_b_z.get()), float(self.b3_entry_0_r.get()),
                    float(self.b3_entry_1_r.get()), float(self.b3_entry_b0.get()), float(self.b3_entry_b1.get()),
                    float(self.b3_entry_0_g.get()), float(self.b3_entry_1_g.get()))
                w = 1
                previousX = 1 - (1 - float(self.b3_entry_0_g.get())) * math.cos(w*math.pi/2) \
                            - float(self.b3_entry_0_g.get()) * math.cos(w*3*math.pi/2)
                previousY = float(X[0,0]*w + X[0,1]*math.pow(w,2) + X[0,2]*math.pow(w,3) + X[0,3]*math.pow(w,4)
                                      + X[0,4]*math.pow(w,5))
                data = data + str(previousX) + "," + str(previousY) + ","
                for i in range(0, 20):
                    u = 0.5*i/19
                    w=1-2*u
                    myCanvasX = 1 - (1 - float(self.b3_entry_0_g.get())) * math.cos(w*math.pi/2) \
                                - float(self.b3_entry_0_g.get()) * math.cos(w*3*math.pi/2)
                    myCanvasY = float(X[0,0]*w + X[0,1]*math.pow(w,2) + X[0,2]*math.pow(w,3) + X[0,3]*math.pow(w,4)
                                      + X[0,4]*math.pow(w,5))
                    data = data + str(myCanvasX) + "," + str(myCanvasY) + ","
                for i in range(0, 20):
                    u = 0.5+0.5*i/19
                    w=2*u-1
                    myCanvasX = 1 - (1 - float(self.b3_entry_1_g.get())) * math.cos(w*math.pi/2) \
                                - float(self.b3_entry_1_g.get()) * math.cos(w*3*math.pi/2)
                    myCanvasY = float(X[1,0]*w + X[1,1]*math.pow(w,2) + X[1,2]*math.pow(w,3) + X[1,3]*math.pow(w,4)
                                      + X[1,4]*math.pow(w,5))
                    data = data + str(myCanvasX) + "," + str(myCanvasY) + ","
                data = data + "0" + ","
                self.sendData(data)
            except ValueError:
                tkinter.messagebox.showerror("Error", "Entries must consist of numerical values and must not be blank.")
        elif(value==3):
            if (self.leftConstraint.current() == 0 or self.rightConstraint.current() == 0):
                tkinter.messagebox.showerror("Error", "Select constraints.")
            else:
                try:
                    points = []
                    tau = ""
                    zeta = ""
                    points = self.listbox.get(0,END)
                    for i in range(0, len(points)):
                        temp = points[i].split(',')
                        if(i < len(points)-1):
                            tau = tau + (temp[0]) + ','
                            zeta = zeta + (temp[1]) + ','
                        else:
                            tau = tau + (temp[0])
                            zeta = zeta + (temp[1])
                    X = pcs.parametricCubicSpline(tau, zeta, self.leftConstraint.current(),
                                                  self.rightConstraint.current())
                    previousX = 1-(1-0.05)*math.sin(math.pi*0) \
                                + 0.05*math.sin(3*math.pi*0)
                    previousY = X[0]
                    data = data + str(previousX) + "," + str(previousY) + ","
                    for i in range(1, 41):
                        u = i/40
                        myCanvasX = 1-(1-0.05)*math.sin(math.pi*u) \
                                    + 0.05*math.sin(3*math.pi*u)
                        myCanvasY = X[i]
                        data = data + str(myCanvasX) + "," + str(myCanvasY) + ","
                    data = data + "0" + ","
                    self.sendData(data)
                except:
                    tkinter.messagebox.showerror("Error", "Add points.")
        elif(value==4):
            try:
                X = pf.parametricFourier(float(self.f_entry_0_g.get()), float(self.f_entry_1_g.get()),
                    float(self.f_entry_le_r.get()), float(self.f_entry_t_u.get()), float(self.f_entry_t_z.get()),
                    float(self.f_entry_b_u.get()), float(self.f_entry_b_z.get()), float(self.f_entry_b0.get()),
                    float(self.f_entry_b1.get()), float(self.f_entry_hte.get()))
                n = 8
                gam = pf.gam_(0, float(self.f_entry_0_g.get()), float(self.f_entry_1_g.get()))
                ww = 1 - 2 * 0
                previousX = pf.X_of_W(gam, ww)
                previousY = float(self.f_entry_hte.get()) * (1 - 2 * 0)
                data = data + str(previousX) + "," + str(previousY) + ","
                for i in range(1, 41):
                    u = i/40
                    gam = pf.gam_(u, float(self.f_entry_0_g.get()), float(self.f_entry_1_g.get()))
                    if(u < 0.5):
                        ww = 1 - 2 * u
                    else:
                        ww = 2 * u - 1
                    xx = pf.X_of_W(gam, ww)
                    zz = float(self.f_entry_hte.get()) * (1 - 2 * u)
                    for j in range(0, n):
                        remain = 1
                        zz = zz + X[j] * math.sin(remain * math.pi * (j+1) * u)
                    data = data + str(xx) + "," + str(zz) + ","
                data = data + "0" + ","
                self.sendData(data)
            except ValueError:
                tkinter.messagebox.showerror("Error", "Entries must consist of numerical values and must not be blank.")
        elif(value==5):
            try:
                for j in range(0, len(self.name)):
                    data = data + str(self.ug[j]) + ","
                    data = data + str(self.lg[j]) + ","
                    data = data + str(self.ler[j]) + ","
                    data = data + str(self.topPointU[j]) + ","
                    data = data + str(self.topPointZ[j]) + ","
                    data = data + str(self.bottomPointU[j]) + ","
                    data = data + str(self.bottomPointZ[j]) + ","
                    data = data + str(self.bu[j]) + ","
                    data = data + str(self.bl[j]) + ","
                    data = data + str(self.hte[j]) + ","
                    data = data + str(self.sparX[j]) + ","
                    data = data + str(self.sparY[j]) + ","
                    data = data + str(self.sparZ[j]) + ","
                    data = data + str(self.scale[j]) + ","
                data = data + "1" + ","
                self.sendData(data)
            except:
                tkinter.messagebox.showerror("Error", "Select a station to plot.")

    #   sendData
    #   - Creates a new socket to send data to Blender
    #   - The Application acts as the client, with Blender the Server, to send data over a port
    def sendData(self, data):
        host = '127.0.0.1'
        port = 7777
        server = ('127.0.0.1', 7777)
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect((host, port))
        s.sendto(str.encode(data[:-1]), server)
        s.close()

    #   resizeWindow
    #   - Checks the current value of the method combobox, appropriately resizing and cenetering the window
    def resizeWindow(self):
        value = self.method.current()
        if(value == 0):
            w = 900
            h = 410
            screenW = self.parent.winfo_screenwidth()
            screenH = self.parent.winfo_screenheight()
            x = (screenW - w) / 2
            y = (screenH - h) / 2
            self.parent.geometry('%dx%d+%d+%d' % (w, h, x, y))
        elif(value == 1):
            w = 900
            h = 450
            screenW = self.parent.winfo_screenwidth()
            screenH = self.parent.winfo_screenheight()
            x = (screenW - w) / 2
            y = (screenH - h) / 2
            self.parent.geometry('%dx%d+%d+%d' % (w, h, x, y))
        elif(value == 2):
            w = 900
            h = 495
            screenW = self.parent.winfo_screenwidth()
            screenH = self.parent.winfo_screenheight()
            x = (screenW - w) / 2
            y = (screenH - h) / 2
            self.parent.geometry('%dx%d+%d+%d' % (w, h, x, y))
        elif(value == 3):
            w = 805
            h = 415
            screenW = self.parent.winfo_screenwidth()
            screenH = self.parent.winfo_screenheight()
            x = (screenW - w) / 2
            y = (screenH - h) / 2
            self.parent.geometry('%dx%d+%d+%d' % (w, h, x, y))
        elif(value == 4):
            w = 900
            h = 425
            screenW = self.parent.winfo_screenwidth()
            screenH = self.parent.winfo_screenheight()
            x = (screenW - w) / 2
            y = (screenH - h) / 2
            self.parent.geometry('%dx%d+%d+%d' % (w, h, x, y))
        elif(value == 5):
            w = 755
            h = 415
            screenW = self.parent.winfo_screenwidth()
            screenH = self.parent.winfo_screenheight()
            x = (screenW - w) / 2
            y = (screenH - h) / 2
            self.parent.geometry('%dx%d+%d+%d' % (w, h, x, y))

    #   centerWindow
    #   - Centers the original frame
    def centerWindow(self):
        w = 900
        h = 280
        screenW = self.parent.winfo_screenwidth()
        screenH = self.parent.winfo_screenheight()
        x = (screenW - w) / 2
        y = (screenH - h) / 2
        self.parent.geometry('%dx%d+%d+%d' % (w, h, x, y))

    def exitCheck(self):
        if tkinter.messagebox.askyesno("Confirm Exit", "Are you sure you want to exit the program?"):
            self.parent.destroy()

#   Main Loop
#   - Calls tKinter and the Application Class
def main():
    root = Tk()
    app = AircraftGenerator(root)
    app.pack(side="top", fill="both", expand=True)
    root.mainloop()

if __name__ == '__main__':
    main()