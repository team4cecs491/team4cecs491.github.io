#   CSULB - Northrop Grumman Student Design Project
#   Parametric Fourier
#   Originally Written By Phil Barnes of NGC
#   Slight Modifications by Marvin Trajano, Lisa Tran, Victor Tran
#   Spring 2015

import math
import numpy as np
import tkinter.messagebox

#   parametricFourier
#   - Takes in a number of values (8 if points are considered as one) to fine tune the upper and lower halves of an
#     airfoil, the result maintains continuity on all derivatives, an important characteristic in airfoil design
def parametricFourier(g_t, g_b, r, x_t, z_t, x_b, z_b, b_t, b_b, z):
    n = 8
    FF = np.matrix(np.zeros((n, n)))
    BB = np.array(np.zeros(n))
    for i in range(1,4):
        if(i == 1):
            wt = W_of_X(g_t, x_t)
            wb = W_of_X(g_b, x_b)
        else:
            ut = 0.5 * (1 - wt)
            gam = gam_(ut, g_t, g_b)
            wt = W_of_X(gam, x_t)
            ub = 0.5 * (1 + wb)
            gam = gam_(ub, g_t, g_b)
            wb = W_of_X(gam, x_b)

    gama = 0.5 * (g_t + g_b)
    for i in range(0, n):
        if(i == 0):
            uu = 0
            ww = 1
            zz = 0 + z
            dZdU = math.pi * math.tan(b_t * (math.pi / 180) * (1 - 4 * g_t))
        elif(i == 1 or i == 2):
            uu = ut
            ww = wt
            zz = z_t
            dZdU = 0
        elif(i == 3 or i == 4):
            uu = 0.5
            ww = 0
            zz = 0
            dZdU = -1 * math.sqrt(r * (1+8*gama) * math.pi**2)
        elif(i == 5 or i == 6):
            uu = ub
            ww = wb
            zz = z_b
            dZdU = 0
        elif(i == 7):
            uu = 1
            ww = 1
            zz = 0 - z
            dZdU = math.pi * math.tan(b_b * (math.pi/180)) * (1 - 4 * g_b)
        gam = gam_(uu, g_t, g_b)
        xx = X_of_W(gam, ww)
        if(i != 1 and i != 4 and i != 5):
            BB[i] = dZdU + 2 * z
        else:
            BB[i] = zz - z * (1 - 2 * uu)
        for j in range(0, n):
            remain = 1
            if(i != 1 and i != 4 and i != 5):
                FF[i,j] = math.pi * (j+1) * math.cos(remain * math.pi * (j+1) * uu)
            else:
                FF[i,j] = math.sin(remain * math.pi * (j+1) * uu)
    try:
        PP = np.linalg.solve(FF,BB)
        return PP
    except:
        tkinter.messagebox.showerror("Error", "Matrix error.")

def W_of_X(gamma, xx):
    expo = 0.56
    xe = xx ** expo
    w_of_x = xe - 1.3 * gamma * math.sin(math.pi * xe ** 2)
    for i in range(1,5):
        x1 = X_of_W(gamma, w_of_x)
        xe1 = x1 ** expo
        w_of_x = w_of_x + xe - xe1
    return w_of_x

def X_of_W(gamma, ww):
    x_of_w = 1 - (1 - gamma) * math.cos(ww * math.pi / 2) - gamma * math.cos(ww * 3 * math.pi / 2)
    return x_of_w

def gam_(uu, g_t, g_b):
    gam = g_b + (g_t - g_b) * (math.cos(uu * (math.pi / 2))) ** 2
    return gam