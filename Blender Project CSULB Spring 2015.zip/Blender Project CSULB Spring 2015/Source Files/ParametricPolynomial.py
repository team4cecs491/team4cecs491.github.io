#   CSULB - Northrop Grumman Student Design Project
#   Parametric Polynomial
#   Written by Marvin Trajano, Lisa Tran, Victor Tran
#   Spring 2015

import numpy as np
import math
import tkinter.messagebox

#   boundaryOne
#   - Takes in a leading edge points, upper trailing edge point, lower trailing edge point, leading edge radius, beta
#     upper angle, beta lower angle, and gamma to calculate a polynomial for an airfoil
def boundaryOne(u_e, z_e, u_0, z_0, u_1, z_1, r, b0, b1, gamma):
    d2xdu2 = math.pi*math.pi*math.sin(math.pi*u_e)*(1-gamma)-9*math.pi*math.pi*gamma*math.sin(3*math.pi*u_e)
    #Set up matrices
    A = np.matrix(np.zeros((5,5)))
    for i in range(0, 5):
        A[0, i] = math.pow(u_e, i+1)
    for i in range(0, 5):
        A[1, i] = math.pow(u_1, i+1)
    for i in range(0, 5):
        A[2, i] = math.pow(u_0, i)*(i+1)
    for i in range(0, 5):
        A[3, i] = math.pow(u_1, i)*(i+1)
    for i in range(0, 5):
        A[4, i] = math.pow(u_e, i)*(i+1)

    B = np.array(np.zeros(5))
    B[0] = z_e - z_0*(1-2*u_e)
    B[1] = z_1 - z_0*(1-2*u_1)
    B[2] = math.pi*math.tan(b0*math.pi/180)*(1-4*gamma) + 2*z_0
    B[3] = math.pi*math.tan(b1*math.pi/180)*(1-4*gamma) + 2*z_0
    B[4] = -1*math.pow((r*(d2xdu2)), 0.5) + 2*z_0
    #Solve matrices for polynomial
    try:
        X = np.linalg.solve(A, B)
        return X
    except:
        tkinter.messagebox.showerror("Error", "Matrix error.")

#   boundaryTwo
#   - Takes in a leading edge points, upper trailing edge point, lower trailing edge point, top point, bottom point,
#     leading edge radius, beta upper angle, beta lower angle, and gamma to calculate a polynomial for an airfoil
def boundaryTwo(u_e, z_e, u_0, z_0, u_1, z_1, r, b0, b1, gamma, u_t, z_t, u_b, z_b):
    d2xdu2 = math.pi*math.pi*math.sin(math.pi*u_e)*(1-gamma)-9*math.pi*math.pi*gamma*math.sin(3*math.pi*u_e)
    #Set up matrices
    A = np.matrix(np.zeros((7,7)))
    for i in range(0, 7):
        A[0, i] = math.pow(u_e, i+1)
    for i in range(0, 7):
        A[1, i] = math.pow(u_1, i+1)
    for i in range(0, 7):
        A[2, i] = math.pow(u_0, i)*(i+1)
    for i in range(0, 7):
        A[3, i] = math.pow(u_1, i)*(i+1)
    for i in range(0, 7):
        A[4, i] = math.pow(u_e, i)*(i+1)
    for i in range(0, 7):
        A[5, i] = math.pow(u_t, i+1)
    for i in range(0, 7):
        A[6, i] = math.pow(u_b, i+1)
    B = np.array(np.zeros(7))
    B[0] = z_e - z_0*(1-2*u_e)
    B[1] = z_1 - z_0*(1-2*u_1)
    B[2] = math.pi*math.tan(b0*math.pi/180)*(1-4*gamma) + 2*z_0
    B[3] = math.pi*math.tan(b1*math.pi/180)*(1-4*gamma) + 2*z_0
    B[4] = -1*math.pow((r*(d2xdu2)), 0.5) + 2*z_0
    B[5] = z_t - (z_0*(1-2*u_t))
    B[6] = z_b - (z_0*(1-2*u_b))
    #Solve matrices for polynomial
    try:
        X = np.linalg.solve(A, B)
        return X
    except:
        tkinter.messagebox.showerror("Error", "Matrix error.")

#   boundaryThree
#   - Takes in a leading edge points, upper trailing edge point, lower trailing edge point, top point, bottom point,
#     upper leading edge radius, lower leading edge radius, beta upper angle, beta lower angle, upper gamma, and lower
#     gamma to calculate a polynomial for an airfoil
def boundaryThree(u_e, z_e, u_0, z_0, u_1, z_1, u_t, z_t, u_b, z_b, r_0, r_1, b0, b1, g0, g1):
    d2xdu2 = math.pi*math.pi*math.sin(math.pi*u_e)*(1-g0)-9*math.pi*math.pi*g0*math.sin(3*math.pi*u_e)
    #Upper half matrices
    A = np.matrix(np.zeros((5,5)))
    for i in range(0, 5):
        A[0, i] = math.pow(0, i)*(i+1)
    for i in range(0, 5):
        A[1, i] = math.pow(u_t, i+1)
    for i in range(0, 5):
        A[2, i] = math.pow(u_t, i)*(i+1)
    for i in range(0, 5):
        A[3, i] = math.pow(1, i)
    for i in range(0, 5):
        A[4, i] = math.pow(1, i)*(i+1)
    B = np.array(np.zeros(5))
    B[0] = math.pow((r_0*(d2xdu2)), 0.5) / 2
    B[1] = z_t
    B[2] = 0
    B[3] = z_0
    B[4] = -1*math.tan(b0*math.pi/180)*(math.pi/2)*(1-4*g0)
    try:
        x_upper = np.linalg.solve(A, B)
    except:
        tkinter.messagebox.showerror("Error", "Matrix error.")
    #Lower Matrices
    d2xdu2 = math.pi*math.pi*math.sin(math.pi*u_e)*(1-g1)-9*math.pi*math.pi*g1*math.sin(3*math.pi*u_e)
    for i in range(0, 5):
        A[0, i] = math.pow(0, i)*(i+1)
    for i in range(0, 5):
        A[1, i] = math.pow(u_b, i+1)
    for i in range(0, 5):
        A[2, i] = math.pow(u_b, i)*(i+1)
    for i in range(0, 5):
        A[3, i] = math.pow(1, i)
    for i in range(0, 5):
        A[4, i] = math.pow(1, i)*(i+1)
    B = np.array(np.zeros(5))
    B[0] = -1*math.pow((r_1*(d2xdu2)), 0.5) / 2
    B[1] = z_b
    B[2] = 0
    B[3] = z_1
    B[4] = math.tan(b1*math.pi/180)*(math.pi/2)*(1-4*g1)
    x_lower = np.linalg.solve(A, B)
    X = np.matrix(np.zeros((2,5)))
    for i in range(0,5):
        X[0, i] = x_upper[i]
    for i in range(0, 5):
        X[1, i] = x_lower[i]
    return X