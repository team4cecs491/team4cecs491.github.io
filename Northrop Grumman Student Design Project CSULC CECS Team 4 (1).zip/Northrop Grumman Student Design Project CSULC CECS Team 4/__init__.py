# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

bl_info = {
    "name": "Aircraft Components",
    "author": "CSULB CECS 491 Team 4",
    "version": (1, 0),
    "blender": (2, 70, 0),
    "location": "View3D > Add > Mesh > Aircraft Components",
    "description": "Add aircraft components",
    "category": "Add Mesh",
}

#Initialize files
if "bpy" in locals():
    import imp
    imp.reload(add_mesh_wing)
    imp.reload(add_mesh_symmetrical_wings)
    imp.reload(add_mesh_pod)
    imp.reload(add_mesh_fuselage)
    imp.reload(update_component)
    imp.reload(add_mesh_3d_function_surface_edited)
else:
    from . import add_mesh_wing
    from . import add_mesh_symmetrical_wings
    from . import add_mesh_pod
    from . import add_mesh_fuselage
    from . import update_component
    from . import add_mesh_3d_function_surface_edited

import bpy
from bpy.props import *

#Enables aircraft generator in the menu
class mesh_aircraft_components_add(bpy.types.Menu):
    bl_idname = "mesh_aircraft_components_add"
    bl_label = "Aircraft Components"

    def draw(self, context):
        layout = self.layout
        layout.operator_context = 'INVOKE_REGION_WIN'
        layout.operator("mesh.wing_add", text="Wing")
        layout.operator("mesh.symmetrical_wings_add", text="Symmetrical Wings")
        layout.operator("mesh.pod_add", text="Pod")
        layout.operator("mesh.fuselage_add", text="Fuselage")

#Enables aircraft generator in the left-hand Tools UI
class aircraft_component_panel(bpy.types.Panel):
    """Aircraft Component Panel"""
    bl_idname = "panel_aircraft_components_add"
    bl_label = "Add Aircraft Component"
    
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'TOOLS'
    bl_category = 'Aircraft Generator'
    
    def draw(self, context):
        layout = self.layout
        layout.operator("mesh.wing_add", text="Wing")
        layout.operator("mesh.symmetrical_wings_add", text="Symmetrical Wing")
        layout.operator("mesh.pod_add", text="Pod")
        layout.operator("mesh.fuselage_add", text="Fuselage")

#Error Message Generator
class error_message(bpy.types.Operator):
    bl_idname = "error.error_message"
    bl_label = "Message"
    message_type = StringProperty()
 
    def execute(self, context):
        return {'FINISHED'}
 
    def invoke(self, context, event):
        wm = context.window_manager
        return wm.invoke_popup(self, width=300, height=200)
 
    def draw(self, context):
        if self.message_type == "SINGULAR_MATRIX":
            self.layout.label("Singular Matrix Error")
            self.layout.label("Component not created, "
                              "please check Tau and Zeta values.")
        elif self.message_type == "NEGATIVE_VALUE":
            self.layout.label("Negative Value Error")
            self.layout.label("Component not created, "
                              "please check component values.")
        elif self.message_type == "TAU_ZETA_OFFSET":
            self.layout.label("Incompatible Points Error")
            self.layout.label("Tau points are not compatible "
                              "with the other points.")
        elif self.message_type == "INVALID_FLOAT":
            self.layout.label("Floating Point Error")
            self.layout.label("Invalid float point found.")
        elif self.message_type == "FILE_NOT_FOUND":
            self.layout.label("File Error")
            self.layout.label("File not found.")
        else:
            self.layout.label("A message has arrived!")

#Registers addon in menu with new icon
def menu_func(self, context):
    self.layout.menu("mesh_aircraft_components_add", icon="FORCE_DRAG")

def register():
    bpy.utils.register_module(__name__)
    bpy.types.INFO_MT_mesh_add.append(menu_func)

def unregister():
    bpy.utils.unregister_module(__name__)
    bpy.types.INFO_MT_mesh_add.remove(menu_func)

if __name__ == "__main__":
    register()
