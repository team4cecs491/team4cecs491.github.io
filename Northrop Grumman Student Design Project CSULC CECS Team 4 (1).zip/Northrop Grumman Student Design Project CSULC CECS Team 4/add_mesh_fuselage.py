# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

bl_info = {
    "name": "Add Fuselage",
    "author": "CSULB CECS 491 Team 4",
    "version": (1, 0),
    "blender": (2, 70, 0),
    "description": "Generates a fuselage with parametric cubic splines.",
    "category": "Object"
}

import bpy, math
import numpy as np
import csv
from bpy.props import *

#Constants
RADIANS_TO_DEGREES = 57.2957795
TAU_DEFAULT = "0.0, 0.5, 0.83666, 1.0"
ZETA_DEFAULT = "1.00, 0.005, 0.08, 0.04, 0.005, -0.5"
UPPER_DEFAULT = "1.00, 0.0, 0.2, 0.19, 0.16, -0.6"
LOWER_DEFAULT = "1.00, 0.0, 0.0, 0.11, 0.14, 0.4"
PLACEMENT_DEFAULT = "0.0, 0.0, 0.05, 0.15, 0.15, 1.0"

#Creates a new material for an object
def makeMaterial(color, diffuse, specular, alpha):
    mat = bpy.data.materials.new(color)
    mat.diffuse_color = diffuse
    mat.diffuse_shader = 'LAMBERT' 
    mat.diffuse_intensity = 1.0 
    mat.specular_color = specular
    mat.specular_shader = 'COOKTORR'
    mat.specular_intensity = 0.5
    mat.alpha = alpha
    mat.ambient = 1
    return mat

#Sets the object to the material
def setMaterial(ob, mat):
    me = ob.data
    me.materials.append(mat)

#Gets "Tau Point" input data from a CSV file,
#converting Strings to arrays
def getTauPoints(file_location):
    with open(file_location, 'r') as f:
        mycsv = csv.reader(f)
        mycsv = list(mycsv)
        tauMax = 1
        for i in range(1, len(mycsv)):
            if mycsv[i][0] is not '':
                tauMax +=1
        tauString = ""
        for i in range(1,tauMax):
            if i == tauMax-1:
                tauString += mycsv[i][0]
            else:
                tauString += mycsv[i][0]+', '
        f.close()
    return tauString;

#Gets "Zeta Point" input data from a CSV file,
#converting Strings to arrays
def getZetaPoints(file_location):
    with open(file_location, 'r') as f:
        mycsv = csv.reader(f)
        mycsv = list(mycsv)
        zetaString = ""
        zetaMax = 1
        for i in range(1, len(mycsv)):
            if mycsv[i][1] is not '':
                zetaMax +=1
        for i in range(1,zetaMax):
            if i == zetaMax-1:
                zetaString += mycsv[i][1]
            else:
                zetaString += mycsv[i][1]+', '
        f.close()
    return zetaString;

#Gets "Upper, Lower, and Placement Points" from a CSV file,
#converting Strings to arrays
def getFuselagePoints(file_location):
    with open(file_location, 'r') as f:
        mycsv = csv.reader(f)
        mycsv = list(mycsv)
        upperMax = 1
        lowerMax = 1
        placementMax = 1
        upperString = ""
        lowerString = ""
        placementString = ""
        #find number of upper lower and placement
        for i in range(1, len(mycsv)):
            if mycsv[i][2] is not '':
                upperMax+=1
            if mycsv[i][3] is not '':
                lowerMax +=1 
            if mycsv[i][4] is not '':
                placementMax +=1 
        #set upper lower and placement strings
        for i in range(1, upperMax):
            if i == upperMax - 1:
                upperString += mycsv[i][2]
            else:
                upperString += mycsv[i][2] + ', '
        for i in range(1, lowerMax):
            if i == lowerMax - 1:
                lowerString += mycsv[i][3]
            else:
                lowerString += mycsv[i][3] + ', '
        for i in range(1, placementMax):
            if i == placementMax - 1:
                placementString += mycsv[i][4]
            else:
                placementString += mycsv[i][4] + ', '
        
        return [upperString, lowerString, placementString]

#Checks to ensure Tau Points and Zeta Points differ by a maximum of 2
def checkTauZetaOffset(t_points, z_points, u_points, l_points, p_points):
    t_points = t_points.split(',')
    z_points = z_points.split(',')
    u_points = u_points.split(',')
    l_points = l_points.split(',')
    p_points = p_points.split(',')
    z = len(z_points)
    offset = z - len(t_points)
    print("Tau Zeta offset: " + str(offset))
    print("Upper Lower Placement point length (should be the same): "
          + str([len(u_points), len(l_points), len(p_points)]))
    #length of tau is always length of zeta -2
    if offset > 2 or offset < 2:
        return False
    elif len(u_points) is not z or \
         len(l_points) is not z or \
         len(p_points) is not z:
            return False
    else:
        return True

#Validates that points are float values
def validateUserPoints(t_points, z_points, u_points, l_points, p_points):
    print("Validating points...")
    t_split = t_points.split(',')
    z_split = z_points.split(',')
    u_split = u_points.split(',')
    l_split = l_points.split(',')
    p_split = p_points.split(',')
    #Check for valid float
    for i in range(0, len(t_split)):
        try:
            numb = float(t_split[i])
        except ValueError:
            print("Invalid point found: ")
            print("Tau point '" + t_split[i].strip() + "' is not a float.")
            return False
    for i in range(0, len(z_split)):
        try:
            numb = float(z_split[i])
        except ValueError:
            print("Invalid point found: ")
            print("Zeta point '" + z_split[i].strip() +"' is not a float.")
            return False
    #Assuming u, l and p points are same length as they should be
    for i in range(0, len(u_split)):
        try:
            numb = float(u_split[i])
            numb = float(l_split[i])
            numb = float(p_split[i])
        except ValueError:
            print("Invalid point found in set: ")
            print(u_split[i].strip() + ', ' + l_split[i].strip()
                  + ', ' + p_split[i].strip())
            return False
    print("Points validated.")
    return True

#Generates a parametric cubic spline with the input data
def generateSpline(number_of_points, tau_points, zeta_points, n_points):
    #Initialize data
    x_points_string = zeta_points
    time = np.array(np.zeros(number_of_points))
    xx = np.array(np.zeros(number_of_points))
    x_points_string = x_points_string.split(',')
    for i in range(0, len(tau_points)):
        time[i] = tau_points[i]
    for i in range(1, len(x_points_string)-1):
        xx[i-1] = x_points_string[i]
    left_end_constraint = float(x_points_string[0])
    right_end_constraint = float(x_points_string[len(x_points_string)-1])
    velocity = np.array(np.zeros(number_of_points))
    acceleration = np.array(np.zeros(number_of_points))
    number_of_splines = number_of_points - 1
    DEL = np.array(np.zeros(number_of_splines))
    eps = np.array(np.zeros(number_of_splines))
    for i in range(0, number_of_splines):
        DEL[i] = time[i+1] - time[i]
        eps[i] = xx[i+1] - xx[i]
    FF = np.matrix(np.zeros((number_of_points,number_of_points)))
    BB = np.array(np.zeros(number_of_points))
    if(number_of_points < 4 and left_end_constraint == 2):
        left_end_constraint = 1
    if(number_of_points < 4 and right_end_constraint == 2):
        right_end_constraint = 1
    vL = 0
    vR = 0
    #Influence the coefficeient matrix
    if(left_end_constraint != 0 and \
       left_end_constraint != 1 and \
       left_end_constraint != 2):
        vL = left_end_constraint
        left_end_constraint = 3
    if(right_end_constraint != 0 and \
       right_end_constraint != 1 and \
       right_end_constraint != 2):
        vR = right_end_constraint
        right_end_constraint = 3
    for i in range(0, number_of_points):
        for j in range(0, number_of_points):
            FF[i,j] = 0
            if(left_end_constraint == 1 and i == 0 and j == 0):
                FF[i,j] = 1
            elif((left_end_constraint == 3 or \
                 left_end_constraint == 0) and \
                 i == 0 and \
                 j == 0):
                    FF[i,j] = DEL[0] / 3
            elif((left_end_constraint == 3 or \
                 left_end_constraint == 0) and \
                 i == 0 and \
                 j == 1):
                    FF[i,j] = DEL[0] / 6
            elif(left_end_constraint == 2 and i == 0 and j == 0):
                FF[i,j] = 1
            elif(left_end_constraint == 2 and i == 0 and j == 1):
                FF[i,j] = -1 - DEL[0] / DEL[1]
            elif(left_end_constraint == 2 and i == 0 and j == 2):
                FF[i,j] = DEL[0] / DEL[1]
            elif(i > 0 and i < number_of_points - 1):
                if(j == i-1):
                    FF[i,j] = DEL[i-1] / 6
                elif(j == i):
                    FF[i,j] = (DEL[i-1] + DEL[i]) / 3
                elif(j == i+1):
                    FF[i,j] = DEL[i] / 6
            elif(right_end_constraint == 1 and \
                 i == number_of_points - 1 and \
                 j == number_of_points - 1):
                    FF[i,j] = 1
            elif((right_end_constraint == 3 or \
                 right_end_constraint == 0) and \
                 i == number_of_points - 1 and \
                 j == number_of_points - 2):
                    FF[i,j] = -DEL[number_of_splines - 1] / 6
            elif((right_end_constraint == 3 or \
                 right_end_constraint == 0) and \
                 i == number_of_points - 1 and \
                 j == number_of_points - 1):
                    FF[i,j] = -DEL[number_of_splines - 1] / 3
            elif(right_end_constraint == 2 and \
                 i == number_of_points - 1 and \
                 j == number_of_points - 1):
                    FF[i,j] = 1
            elif(right_end_constraint == 2 and \
                 i == number_of_points - 1 and \
                 j == number_of_points - 2):
                    FF[i,j] = (-1 - DEL[number_of_points - 2]
                               / DEL[number_of_points - 3])
            elif(right_end_constraint == 2 and \
                 i == number_of_points - 1 and \
                 j == number_of_points - 3):
                    FF[i,j] = (DEL[number_of_points - 2]
                               / DEL[number_of_points - 3])
        BB[i] = 0
        if(left_end_constraint == 1 and i == 0):
            BB[i] = 0
        elif((left_end_constraint == 3 or left_end_constraint == 0) and i == 0):
            BB[i] = eps[0] / DEL[0] - vL
        elif(left_end_constraint == 2 and i == 0):
            BB[i] = 0
        elif(i > 0 and i < number_of_points - 1):
            BB[i] = eps[i] / DEL[i] - eps[i - 1] / DEL[i - 1]
        elif(right_end_constraint == 1 and i == number_of_points - 1):
            BB[i] = 0
        elif((right_end_constraint == 3 or \
             right_end_constraint == 0) and \
             i == number_of_points - 1):
                BB[i] = (eps[number_of_splines - 1]
                         / DEL[number_of_splines - 1] - vR)
        elif(right_end_constraint == 2 and i == number_of_splines - 1):
            BB[i] = 0
    acceleration = np.linalg.solve(FF,BB)
    #Solve for 1st derivatives
    for i in range(0, number_of_points):
        if(i < number_of_points - 1):
            velocity[i] = (eps[i] / DEL[i] - acceleration[i] * DEL[i]
                           / 3 - acceleration[i+1] * DEL[i] / 6)
        else:
            velocity[i] = (velocity[number_of_splines-1]
                           + acceleration[number_of_splines-1]
                           * DEL[number_of_splines-1] / 2
                           + acceleration[number_of_points-1]
                           * DEL[number_of_splines-1] / 2)          
    #Interpolate
    xArray = np.array(np.zeros(n_points))
    for i in range(0, n_points):
        to_ = i / (n_points - 1)
        if (to_ < time[0]):
            xo_ = xx[0] + velocity[0] * (to_ - time[0])
            '''
            Could be used for future purposes for displaying
            velocity and acceleration data
            vvo = velocity[0] + acceleration[0] * (to_ - time[0])
            d3xdt3 = (acceleration[1] - acceleration[0]) / DEL[0]
            aao = acceleration[0] + d3xdt3 * (to_ - time[0])
            '''
        elif(to_ > time[number_of_points-1]):
            xo_ = (xx[number_of_points-1] + velocity[number_of_points-1]
                   * (to_ - time[number_of_points - 1]))
            '''
            vvo = (velocity[number_of_points - 1]
            + acceleration[number_of_points-1]
            * (to_ - time[number_of_points - 1]))
            d3xdt3 = ((acceleration[number_of_points - 1]
            - acceleration[number_of_points - 2])
            / DEL[number_of_splines-1])
            aao = acceleration[0] + d3xdt3 * (to_ - time[0])
            '''
        else:
            for j in range(0, number_of_splines):
                if(time[j+1] >= to_):
                    tmti = to_ - time[j]
                    epsi = eps[j]
                    DELI = DEL[j]
                    xxi = xx[j]
                    aai = acceleration[j]
                    dxdti = velocity[j]
                    aip1 = acceleration[j+1]
                    xo_ = (xxi + dxdti * tmti + aai * tmti ** 2 / 2
                           + (aip1 - aai) * tmti ** 3 / (6 * DELI))
                    '''
                    vvo = dxdti + aai * tmti + (aip1 - aai)
                    * tmti ** 2 / (2 * DELI)                                                                   
                    aao = aai + (aip1 - aai) * tmti / DELI
                    '''
                    break
        xArray[i] = xo_
    return xArray

#Gets CSV points from an input file location
def useCSV(file_location):
    try:
        print("Using CSV points...")
        #Try to get points from excel sheet
        t_pointsCSV = getTauPoints(file_location)
        z_pointsCSV = getZetaPoints(file_location)

        #fuselagePoints is an array of 3 strings:
        #0th = upper string, 1st = lower string, 2nd = placement string
        fuselagePoints = getFuselagePoints(file_location)
        u_pointsCSV = fuselagePoints[0]
        l_pointsCSV = fuselagePoints[1]
        p_pointsCSV = fuselagePoints[2]
        points = [t_pointsCSV,
                  z_pointsCSV,
                  u_pointsCSV,
                  l_pointsCSV,
                  p_pointsCSV]

    except:
        print("File not found at " + file_location + ".")
        points = [False]
        pass
    return points

#Creates a fuselage from generated parametric cubic spline data
def add_fuselage(tau_points, zeta_points, upper_points, lower_points,
                 placement_points, smoothness, location, rotation, scale,
                 file_location, n_points, upper, lower, width, colorwheel):
    tau_points = tau_points.split(',')
    scalingSpline = generateSpline(len(tau_points),
                                   tau_points,
                                   zeta_points,
                                   n_points)
    upperPlacementSpline = generateSpline(len(tau_points),
                                          tau_points,
                                          upper_points,
                                          n_points)
    lowerPlacementSpline = generateSpline(len(tau_points),
                                          tau_points,
                                          lower_points,
                                          n_points)
    equatorPlacementSpline = generateSpline(len(tau_points),
                                            tau_points,
                                            placement_points,
                                            n_points)
    #Generate cross sections
    x_equation = "0"
    #Generate upper cross sections
    for i in range(0, n_points):
        to_ = i / (n_points - 1)
        y_equation = str(width*scalingSpline[i]) + "*cos(u)"  
        z_equation = (str(upper*(upperPlacementSpline[i]
                                 -equatorPlacementSpline[i]))
                                 + "*sin(u)")
        bpy.ops.mesh.primitive_xyz_function_surface_edited(x_eq=y_equation,
                                                           y_eq=x_equation,
                                                           z_eq=z_equation,
                                                           range_u_min=0,
                                                           range_u_max=3.14,
                                                           range_u_step=smoothness,
                                                           wrap_u = False,
                                                           close_v = False)
        bpy.context.object.location[0] = 0
        bpy.context.object.location[1] = to_ ** 2
        bpy.context.object.location[2] = equatorPlacementSpline[i]    
    for obs in bpy.context.scene.objects:
        if obs.name[0:26] == 'AIRCRAFT GENERATED OBJ ***':
            obs.select = True
            bpy.context.scene.objects.active = obs
        else:
            obs.select = False
    bpy.ops.object.join()
    bpy.context.tool_settings.mesh_select_mode = (False, True, False)
    fuse = bpy.context.active_object
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.mesh.bridge_edge_loops()
    bpy.ops.object.mode_set(mode='OBJECT')
    fuse.name = "*** PLACEHOLDER ***"
    #Generate lower cross sections
    for i in range(0, n_points):
        to_ = i / (n_points - 1)
        y_equation = str(width*scalingSpline[i]) + "*cos(u)"  
        z_equation = (str(lower*(equatorPlacementSpline[i]
                                 -lowerPlacementSpline[i]))
                                 + "*sin(u)")
        bpy.ops.mesh.primitive_xyz_function_surface_edited(x_eq=y_equation,
                                                           y_eq=x_equation,
                                                           z_eq=z_equation,
                                                           range_u_min=0,
                                                           range_u_max=-3.15,
                                                           range_u_step=smoothness,
                                                           wrap_u = False,
                                                           close_v = False)
        bpy.context.object.location[0] = 0
        bpy.context.object.location[1] = to_ ** 2
        bpy.context.object.location[2] = equatorPlacementSpline[i]
    bpy.ops.object.select_all(action='DESELECT')    
    for obs in bpy.context.scene.objects:
        if obs.name[0:26] == 'AIRCRAFT GENERATED OBJ ***':
            obs.select = True
            bpy.context.scene.objects.active = obs
        else:
            obs.select = False
    bpy.ops.object.join()
    bpy.context.tool_settings.mesh_select_mode = (False, True, False)
    fuse = bpy.context.active_object
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.mesh.bridge_edge_loops()
    bpy.ops.object.mode_set(mode='OBJECT')
    #Merge upper and lower sections
    for obs in bpy.context.scene.objects:
        if obs.name[0:26] == 'AIRCRAFT GENERATED OBJ ***' or \
           obs.name == "*** PLACEHOLDER ***":
                obs.select = True
                bpy.context.scene.objects.active = obs
        else:
            obs.select = False
    bpy.ops.object.join()
    #Remove double vertices
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.mesh.remove_doubles()
    bpy.ops.object.mode_set(mode='OBJECT')
    #Set location
    bpy.context.object.location[0] = location[0]
    bpy.context.object.location[1] = location[1]
    bpy.context.object.location[2] = location[2]
    #Set rotation
    for i in range (0,3):
        rotation[i] = math.radians(rotation[i])
    bpy.context.object.rotation_euler[0] = rotation[0]
    bpy.context.object.rotation_euler[1] = rotation[1]
    bpy.context.object.rotation_euler[2] = rotation[2]
    #Set scale
    bpy.context.object.scale[0] = scale[0]
    bpy.context.object.scale[1] = scale[1]
    bpy.context.object.scale[2] = scale[2]
    print("Fuselage created successfully.")
    print("----------------------------------------")

#The operator class that will take in inputs for generating a fuselage
class Fuselage(bpy.types.Operator):
    '''Fuselage generator'''
    bl_idname = "mesh.fuselage_add"
    bl_label = "Add a fuselage"
    bl_options = {'REGISTER', 'UNDO'}
    
    #Properties
    idname = StringProperty(name="Unique Identifier",
                            default = "Fuselage")
    
    use_csv = BoolProperty(name = "Use CSV",
                           default = False,
                           description = "Use CSV file")
    
    file_location = StringProperty(name="File Location",
                                   default="C:/fuselage.csv")
    
    tau_points = StringProperty(name="Tau points",
                                description="Independent variable 'Time'",
                                default="0.0, 0.5, 0.83666, 1.0")
    
    zeta_points = StringProperty(name="Zeta points",
                                 description="User input points",
                                 default="1.00, 0.005, 0.08, 0.04, 0.005, -0.5")
    
    upper_points = StringProperty(name="Upper points",
                                  description="User input points",
                                  default="1.00, 0.0, 0.2, 0.19, 0.16, -0.6")
    
    lower_points = StringProperty(name="Lower points",
                                  description="User input points",
                                  default="1.00, 0.0, 0.0, 0.11, 0.14, 0.4")
    
    placement_points = StringProperty(name="Placement points",
                                      description="User input points",
                                      default="0.0, 0.0, 0.05, 0.15, 0.15, 1.0")
    
    smoothness = IntProperty(name="X-Z Smoothness",
                             description="Smoothness of the fuselage",
                             default = 20,
                             min=2)
    
    n_points = IntProperty(name="Y-Z Smoothness",
                           description="Number of points on the parametric cubic spline",
                           default = 20,
                           min=2)
    
    upper = FloatProperty(name="Upper height",
                          description="Height of fuselage upper",
                          default = 1)
    
    lower = FloatProperty(name="Lower height",
                          description="Height of fuselage lower",
                          default = 1)
    
    width = FloatProperty(name="Width",
                          description="Width of fuselage",
                          default = 1)
    
    location = FloatVectorProperty(name="Location",
                                   default = (0.0, 0.0, 0.0),
                                   subtype='XYZ')
    
    rotation = FloatVectorProperty(name="Rotation",
                                   default = (0.0, 0.0, 0.0),
                                   subtype='XYZ')
    
    scale = FloatVectorProperty(name="Scale",
                                default = (1.0, 1.0, 1.0),
                                subtype='XYZ')
    
    colorwheel = FloatVectorProperty(name="Color",
                                     default = (0.184, 0.174, 0.174),
                                     subtype='COLOR')

    def draw(self, context):
        layout = self.layout
        col = layout.column()
        layout.prop(self, "idname")
        layout.prop(self, "file_location")
        layout.prop(self, "use_csv")
        layout.prop(self, "tau_points")
        layout.prop(self, "zeta_points")
        layout.prop(self, "upper_points")
        layout.prop(self, "lower_points")
        layout.prop(self, "placement_points")
        layout.prop(self, "n_points")
        layout.prop(self, "smoothness")
        layout.prop(self, "location")
        layout.prop(self, "rotation")
        layout.prop(self, "scale")
        layout.prop(self, "upper")
        layout.prop(self, "lower")
        layout.prop(self, "width")
        layout.prop(self, "colorwheel")

    def execute(self, context):
        print("")
        if self.use_csv:
            points = useCSV(self.file_location)
            if points[0] is False:
                bpy.ops.error.error_message('INVOKE_DEFAULT',
                                            message_type = 'FILE_NOT_FOUND')
                return {'FINISHED'}
            self.tau_points = points[0]
            self.zeta_points = points[1]
            self.upper_points = points[2]
            self.lower_points = points[3]
            self.placement_points = points[4]
            #validate points
            if not checkTauZetaOffset(self.tau_points,
                                      self.zeta_points,
                                      self.upper_points,
                                      self.lower_points,
                                      self.placement_points):
                print("TAU ZETA UPPER LOWER PLACEMENT OFFSET > or < 2")
                bpy.ops.error.error_message('INVOKE_DEFAULT',
                                            message_type = 'TAU_ZETA_OFFSET')
                return{'FINISHED'}
            if not validateUserPoints(self.tau_points,
                                      self.zeta_points,
                                      self.upper_points,
                                      self.lower_points,
                                      self.placement_points):
                bpy.ops.error.error_message('INVOKE_DEFAULT',
                                            message_type = 'INVALID_FLOAT')
                return{'FINISHED'}
        elif not checkTauZetaOffset(self.tau_points,
                                    self.zeta_points,
                                    self.upper_points,
                                    self.lower_points,
                                    self.placement_points):
            print("TAU ZETA UPPER LOWER PLACEMENT OFFSET > or < 2")
            bpy.ops.error.error_message('INVOKE_DEFAULT',
                                        message_type = 'TAU_ZETA_OFFSET')
            return{'FINISHED'}
        elif not validateUserPoints(self.tau_points,
                                    self.zeta_points,
                                    self.upper_points,
                                    self.lower_points,
                                    self.placement_points):
            bpy.ops.error.error_message('INVOKE_DEFAULT',
                                        message_type = 'INVALID_FLOAT')
            return {'FINISHED'}

        try:
            ob = add_fuselage(self.tau_points,
                              self.zeta_points,
                              self.upper_points,
                              self.lower_points,
                              self.placement_points,
                              self.smoothness,
                              self.location,
                              self.rotation,
                              self.scale,
                              self.file_location,
                              self.n_points,
                              self.upper,
                              self.lower,
                              self.width,
                              self.colorwheel)
        except:
            print("Singular Matrix error.")
            bpy.ops.error.error_message('INVOKE_DEFAULT',
                                        message_type = 'SINGULAR_MATRIX')
            return {'FINISHED'}
        ob = bpy.context.active_object
        ob["component"] = "fuselage"
        bpy.types.Object.use_csv = self.use_csv
        ob["file_location"] = self.file_location
        ob["tau_points"] = self.tau_points
        ob["zeta_points"] = self.zeta_points
        ob["upper_points"] = self.upper_points
        ob["lower_points"] = self.lower_points
        ob["placement_points"] = self.placement_points
        ob["smoothness"] = self.smoothness
        ob["n_points"] = self.n_points
        ob["upper"] = self.upper
        ob["lower"] = self.lower
        ob["width"] = self.width
        ob["colorwheel"] = self.colorwheel
        ob.name = self.idname
        bpy.ops.object.material_slot_remove()
        color = makeMaterial('Color', self.colorwheel, (1,1,1), 1)
        setMaterial(bpy.context.object, color)
        bpy.ops.view3d.obj_search_refresh()
        return {'FINISHED'}

    def invoke(self, context, event):
        wm = context.window_manager
        return wm.invoke_props_dialog(self)

#Operator class to update an existing fuselage
class updateFuselage(bpy.types.Operator):
    bl_idname = "mesh.fuselage_update"
    bl_label = "Update fuselage"
    bl_options = {'INTERNAL'}

    def execute(self, context):
        print("")
        wm = context.window_manager.MyProperties
        scn = context.scene
        for obj in scn.objects:
            if obj.select == True:
                ob = obj
                break
                #convert radians back to degrees
        for i in range(0,3):
            ob.rotation_euler[i] = ob.rotation_euler[i] * RADIANS_TO_DEGREES
        #Validate update inputs
        if(ob["smoothness"] < 0 or \
           ob["n_points"] < 0 or \
           ob["upper"] < 0 or \
           ob["lower"] < 0 or \
           ob["width"] < 0):
                bpy.ops.error.error_message('INVOKE_DEFAULT',
                                            message_type = 'NEGATIVE_VALUE')
                return {'FINISHED'}
        if not checkTauZetaOffset(ob["tau_points"],
                                  ob["zeta_points"],
                                  ob["upper_points"],
                                  ob["lower_points"],
                                  ob["placement_points"]):
            print("TAU ZETA UPPER LOWER PLACEMENT OFFSET > or < 2")
            bpy.ops.error.error_message('INVOKE_DEFAULT',
                                        message_type = 'TAU_ZETA_OFFSET')
            return{'FINISHED'}
        if not validateUserPoints(ob["tau_points"],
                                  ob["zeta_points"],
                                  ob["upper_points"],
                                  ob["lower_points"],
                                  ob["placement_points"]):
            bpy.ops.error.error_message('INVOKE_DEFAULT',
                                        message_type = 'INVALID_FLOAT')
            return{'FINISHED'}
        try:
            newOb = add_fuselage(ob["tau_points"],
                                 ob["zeta_points"],
                                 ob["upper_points"],
                                 ob["lower_points"],
                                 ob["placement_points"],
                                 ob["smoothness"],
                                 ob.location,
                                 ob.rotation_euler,
                                 ob.scale,
                                 ob["file_location"],
                                 ob["n_points"],
                                 ob["upper"],
                                 ob["lower"],
                                 ob["width"],
                                 ob["colorwheel"])
        except:
            bpy.ops.error.error_message('INVOKE_DEFAULT',
                                        message_type = 'SINGULAR_MATRIX')
            return {'FINISHED'}
        newOb = bpy.context.active_object
        holder = ob.name
        newOb["component"] = "fuselage"
        newOb["tau_points"] = ob["tau_points"]
        newOb["zeta_points"] = ob["zeta_points"]
        newOb["upper_points"] = ob["upper_points"]
        newOb["lower_points"] = ob["lower_points"]
        newOb["placement_points"] = ob["placement_points"]
        newOb["smoothness"] = ob["smoothness"]
        newOb["file_location"] = ob["file_location"]
        newOb["n_points"] = ob["n_points"]
        newOb["upper"] = ob["upper"]
        newOb["lower"] = ob["lower"]
        newOb["width"] = ob["width"]
        newOb["colorwheel"] = ob["colorwheel"] 
        ob.select = True
        newOb.select = False
        bpy.ops.object.delete()
        newOb.name = holder
        newOb = bpy.context.active_object
        color = makeMaterial('Color', newOb["colorwheel"], (1,1,1), 1)
        setMaterial(bpy.context.object, color)
        wm.srch_index = -1
        bpy.ops.view3d.obj_search_refresh()
        return {'FINISHED'}

#Operator class to delete a fuselage
class deleteFuselage(bpy.types.Operator):
    bl_idname = "mesh.fuselage_delete"
    bl_label = "Delete fuselage? (Click elsewhere to cancel.)"
    bl_options = {'INTERNAL'}

    def invoke(self, context, event):
        wm = context.window_manager
        return wm.invoke_props_dialog(self)

    def execute(self, context):
        wm = context.window_manager.MyProperties
        scn = context.scene
        for obj in scn.objects:
            if obj.select == True:
                ob = obj
        bpy.ops.object.delete()
        wm.srch_index = -1
        bpy.ops.view3d.obj_search_refresh()
        return {'FINISHED'}
        
#Operator class to add color to a component 
class fuselageColor(bpy.types.Operator):
    bl_idname = "mesh.fuselage_color"
    bl_label = "Add Color"
    bl_options = {'INTERNAL'}

    colorwheel = FloatVectorProperty(name="Color",
                                     default = (0.184, 0.174, 0.174),
                                     subtype='COLOR')

    def invoke(self, context, event):
        wm = context.window_manager
        return wm.invoke_props_dialog(self)

    def execute(self, context):
        wm = context.window_manager.MyProperties
        scn = context.scene
        for obj in scn.objects:
            if obj.select == True:
                ob = obj
        bpy.ops.object.material_slot_remove()   
        color = makeMaterial('Color', self.colorwheel, (1,1,1), 1)
        setMaterial(bpy.context.object, color)
        ob["colorwheel"] = self.colorwheel
        wm.srch_index = -1
        bpy.ops.view3d.obj_search_refresh()
        return {'FINISHED'}

#Operator class to export data to CSV
class exportFuselage(bpy.types.Operator):
    bl_idname = "mesh.fuselage_export"
    bl_label = "Export data to CSV? (Click outside of dialog box to cancel.)"
    bl_options = {'INTERNAL'}
        
    def invoke(self, context, event):
        wm = context.window_manager
        return wm.invoke_props_dialog(self)

    def execute(self, context):
        wm = context.window_manager.MyProperties
        scn = context.scene
        for obj in scn.objects:
            if obj.select == True:
                ob = obj
        file_export = ob['file_location']
        with open(file_export, 'w', newline = '') as f:
            writer = csv.writer(f)
            exportTau = ob['tau_points']
            exportTau = exportTau.split(',')
            exportTau.append('')
            exportTau.append('')
            exportZeta = ob['zeta_points']
            exportZeta = exportZeta.split(',')
            exportUpper = ob['upper_points']
            exportUpper = exportUpper.split(',')
            exportLower = ob['lower_points']
            exportLower = exportLower.split(',')
            exportPlacement = ob['placement_points']
            exportPlacement = exportPlacement.split(',')
            writer.writerow(['Tau', 'Zeta', 'Upper Points', 'Lower Points', 'Placement Points'])
            for i in range(0, len(exportZeta)): 
                writer.writerow([exportTau[i], exportZeta[i], exportUpper[i], exportLower[i], exportPlacement[i]])
            f.close()
        return {'FINISHED'}
