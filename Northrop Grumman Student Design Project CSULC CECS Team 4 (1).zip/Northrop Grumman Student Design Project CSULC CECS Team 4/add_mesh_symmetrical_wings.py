# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

bl_info = {
    "name": "Add Symmetrical Wings",
    "author": "CSULB CECS 491 Team 4",
    "version": (1, 0),
    "blender": (2, 70, 0),
    "description": "Generates two symmetrical wings using parametric cubic splines.",
    "category": "Object"
}

import bpy, math
import numpy as np
import csv
from bpy.props import *

#Constants
PIRAD = 3.14159
TWOPI = 2 * PIRAD
RqD = PIRAD / 180
TAU_DEFAULT = "0.0, 0.03, 0.19, 0.50, 0.88, 1.00"
ZETA_DEFAULT = "1.00, 0.00, 0.0007, -0.049, 0.00, 0.0488, 0.00, 1.00"
RADIANS_TO_DEGREES = 57.2957795

#Creates a new material for an object
def makeMaterial(color, diffuse, specular, alpha):
    mat = bpy.data.materials.new(color)
    mat.diffuse_color = diffuse
    mat.diffuse_shader = 'LAMBERT' 
    mat.diffuse_intensity = 1.0 
    mat.specular_color = specular
    mat.specular_shader = 'COOKTORR'
    mat.specular_intensity = 0.5
    mat.alpha = alpha
    mat.ambient = 1
    return mat

#Sets the object to the material
def setMaterial(ob, mat):
    me = ob.data
    me.materials.append(mat)

#Gets "Tau Point" input data from a CSV file,
#converting Strings to arrays    
def getTauPoints(file_location):
    with open(file_location, 'r') as f:
        mycsv = csv.reader(f)
        mycsv = list(mycsv)
        tauMax = 1
        for i in range(1, len(mycsv)):
            if mycsv[i][0] is not '':
                tauMax +=1
        tauString = ""
        for i in range(1,tauMax):
            if i == tauMax-1:
                tauString += mycsv[i][0]
            else:
                tauString += mycsv[i][0]+', '
        f.close()
    return tauString;

#Gets "Zeta Point" input data from a CSV file,
#converting Strings to arrays
def getZetaPoints(file_location):
    with open(file_location, 'r') as f:
        mycsv = csv.reader(f)
        mycsv = list(mycsv)
        zetaString = ""
        zetaMax = 1
        for i in range(1, len(mycsv)):
            if mycsv[i][1] is not '':
                zetaMax +=1
        for i in range(1,zetaMax):
            if i == zetaMax-1:
                zetaString += mycsv[i][1]
            else:
                zetaString += mycsv[i][1]+', '
        f.close()
    return zetaString;

#Validates that points are float values
def validateUserPoints(t_points, z_points):
    print("Validating points...")
    t_split = t_points.split(',')
    z_split = z_points.split(',')
    for i in range(0, len(t_split)):
        try:
            numb = float(t_split[i])
        except ValueError:
            print("Invalid point found: ")
            print("Tau point '" + t_split[i].strip() + "' is not a float.")
            return False
    for i in range(0, len(z_split)):
        try:
            numb = float(z_split[i])
        except ValueError:
            print("Invalid point found: ")
            print("Zeta point '" + z_split[i].strip() +"' is not a float.")
            return False
    print("Points validated.")
    return True

#Checks to ensure Tau Points and Zeta Points differ by a maximum of 2 
def checkTauZetaOffset(t_points, z_points):
    t_points = t_points.split(',')
    z_points = z_points.split(',')
    offset = len(z_points) - len(t_points)
    print("Tau Zeta offset: " + str(offset))
    #Length of tau is always length of zeta -2
    if offset > 2 or offset < 2:
        return False
    else:
        return True

#Generates a parametric cubic spline with the input data
def generateSpline(number_of_points, tau_points, zeta_points, n_points):
    #Initialize data
    x_points_string = zeta_points
    time = np.array(np.zeros(number_of_points))
    xx = np.array(np.zeros(number_of_points))
    tau_points = tau_points.split(',')
    x_points_string = x_points_string.split(',')
    for i in range(0, len(tau_points)):
        time[i] = tau_points[i]
    for i in range(1, len(x_points_string)-1):
        xx[i-1] = x_points_string[i]
    left_end_constraint = float(x_points_string[0])
    right_end_constraint = float(x_points_string[len(x_points_string)-1])
    velocity = np.array(np.zeros(number_of_points))
    acceleration = np.array(np.zeros(number_of_points))
    number_of_splines = number_of_points - 1
    DEL = np.array(np.zeros(number_of_splines))
    eps = np.array(np.zeros(number_of_splines))
    for i in range(0, number_of_splines):
        DEL[i] = time[i+1] - time[i]
        eps[i] = xx[i+1] - xx[i]
    FF = np.matrix(np.zeros((number_of_points,number_of_points)))
    BB = np.array(np.zeros(number_of_points))
    if(number_of_points < 4 and left_end_constraint == 2):
        left_end_constraint = 1
    if(number_of_points < 4 and right_end_constraint == 2):
        right_end_constraint = 1
    vL = 0
    vR = 0
    #Influence the coefficient matrix
    if(left_end_constraint != 0 and \
       left_end_constraint != 1 and \
       left_end_constraint != 2):
            vL = left_end_constraint
            left_end_constraint = 3
    if(right_end_constraint != 0 and \
       right_end_constraint != 1 and \
       right_end_constraint != 2):
            vR = right_end_constraint
            right_end_constraint = 3
    for i in range(0, number_of_points):
        for j in range(0, number_of_points):
            FF[i,j] = 0
            if(left_end_constraint == 1 and i == 0 and j == 0):
                FF[i,j] = 1
            elif((left_end_constraint == 3 or \
                 left_end_constraint == 0) and \
                 i == 0 and \
                 j == 0):
                    FF[i,j] = DEL[0] / 3
            elif((left_end_constraint == 3 or \
                 left_end_constraint == 0) and \
                 i == 0 and \
                 j == 1):
                    FF[i,j] = DEL[0] / 6
            elif(left_end_constraint == 2 and \
                 i == 0 and \
                 j == 0):
                    FF[i,j] = 1
            elif(left_end_constraint == 2 and \
                 i == 0 and \
                 j == 1):
                    FF[i,j] = -1 - DEL[0] / DEL[1]
            elif(left_end_constraint == 2 and \
                 i == 0 and \
                 j == 2):
                    FF[i,j] = DEL[0] / DEL[1]
            elif(i > 0 and i < number_of_points - 1):
                if(j == i-1):
                    FF[i,j] = DEL[i-1] / 6
                elif(j == i):
                    FF[i,j] = (DEL[i-1] + DEL[i]) / 3
                elif(j == i+1):
                    FF[i,j] = DEL[i] / 6
            elif(right_end_constraint == 1 and \
                 i == number_of_points - 1 and \
                 j == number_of_points - 1):
                    FF[i,j] = 1
            elif((right_end_constraint == 3 or \
                 right_end_constraint == 0) and \
                 i == number_of_points - 1 and \
                 j == number_of_points - 2):
                    FF[i,j] = -DEL[number_of_splines - 1] / 6
            elif((right_end_constraint == 3 or \
                 right_end_constraint == 0) and \
                 i == number_of_points - 1 and \
                 j == number_of_points - 1):
                    FF[i,j] = -DEL[number_of_splines - 1] / 3
            elif(right_end_constraint == 2 and \
                 i == number_of_points - 1 and \
                 j == number_of_points - 1):
                    FF[i,j] = 1
            elif(right_end_constraint == 2 and \
                 i == number_of_points - 1 and \
                 j == number_of_points - 2):
                    FF[i,j] = (-1 - DEL[number_of_points - 2]
                               / DEL[number_of_points - 3])
            elif(right_end_constraint == 2 and \
                 i == number_of_points - 1 and \
                 j == number_of_points - 3):
                    FF[i,j] = (DEL[number_of_points - 2]
                               / DEL[number_of_points - 3])
        BB[i] = 0
        if(left_end_constraint == 1 and i == 0):
            BB[i] = 0
        elif((left_end_constraint == 3 or left_end_constraint == 0) and i == 0):
            BB[i] = eps[0] / DEL[0] - vL
        elif(left_end_constraint == 2 and i == 0):
            BB[i] = 0
        elif(i > 0 and i < number_of_points - 1):
            BB[i] = eps[i] / DEL[i] - eps[i - 1] / DEL[i - 1]
        elif(right_end_constraint == 1 and i == number_of_points - 1):
            BB[i] = 0
        elif((right_end_constraint == 3 or \
             right_end_constraint == 0) and \
             i == number_of_points - 1):
                BB[i] = (eps[number_of_splines - 1]
                         / DEL[number_of_splines - 1] - vR)
        elif(right_end_constraint == 2 and i == number_of_splines - 1):
            BB[i] = 0
    acceleration = np.linalg.solve(FF,BB)
    #Solve for 1st derivatives
    for i in range(0, number_of_points):
        if(i < number_of_points - 1):
            velocity[i] = (eps[i] / DEL[i] - acceleration[i]
                           * DEL[i] / 3 - acceleration[i+1] * DEL[i] / 6)
        else:
            velocity[i] = (velocity[number_of_splines-1]
                           + acceleration[number_of_splines-1]
                           * DEL[number_of_splines-1] / 2
                           + acceleration[number_of_points-1]
                           * DEL[number_of_splines-1] / 2)        
    #Interpolate
    xArray = np.array(np.zeros(n_points))
    for i in range(0, n_points):
        to_ = i / (n_points - 1)
        if (to_ < time[0]):
            xo_ = xx[0] + velocity[0] * (to_ - time[0])
            '''
            Could be used for future purposes for displaying
            velocity and acceleration data
            vvo = velocity[0] + acceleration[0] * (to_ - time[0])
            d3xdt3 = (acceleration[1] - acceleration[0]) / DEL[0]
            aao = acceleration[0] + d3xdt3 * (to_ - time[0])
            '''
        elif(to_ > time[number_of_points-1]):
            xo_ = (xx[number_of_points-1] + velocity[number_of_points-1]
                   * (to_ - time[number_of_points - 1]))
            '''
            vvo = (velocity[number_of_points - 1]
            + acceleration[number_of_points-1]
            * (to_ - time[number_of_points - 1]))
            d3xdt3 = ((acceleration[number_of_points - 1]
            - acceleration[number_of_points - 2])
            / DEL[number_of_splines-1])
            aao = acceleration[0] + d3xdt3 * (to_ - time[0])
            '''
        else:
            for j in range(0, number_of_splines):
                if(time[j+1] >= to_):
                    tmti = to_ - time[j]
                    epsi = eps[j]
                    DELI = DEL[j]
                    xxi = xx[j]
                    aai = acceleration[j]
                    dxdti = velocity[j]
                    aip1 = acceleration[j+1]
                    xo_ = (xxi + dxdti * tmti + aai * tmti ** 2 / 2
                           + (aip1 - aai) * tmti ** 3 / (6 * DELI))
                    '''
                    vvo = dxdti + aai * tmti + (aip1 - aai)
                    * tmti ** 2 / (2 * DELI)                                                                   
                    aao = aai + (aip1 - aai) * tmti / DELI
                    '''
                    break
        xArray[i] = xo_
    return xArray

#Creates a pair of symmetrical wings from generated parametric cubic spline data
def add_wings(delta, tau_points, zeta_points, base_washout, tip_washout, sweep,
              wing_length, inner_space, location, rotation, scale,
              file_location, colorwheel, n_points):
    tau = tau_points.split(',')
    airfoilSpline = generateSpline(len(tau), tau_points, zeta_points, n_points)
    chiValues = np.array(np.zeros(n_points))
    for i in range(0, n_points):
        to_ = i / (n_points - 1)
        chiValues[i] = (1 - (1 - delta) * math.sin(PIRAD * to_)
                        + delta * math.sin(3 * PIRAD * to_))
    #Generate first wing
    #Generate base cross section
    verts = []
    faces = []
    for i in range(0, n_points):
        x = 0
        y = chiValues[i]
        z = airfoilSpline[i]
        vert = (x,y,z) 
        verts.append(vert)
    mesh = bpy.data.meshes.new("AIRFOIL@BASE ***")
    ob = bpy.data.objects.new("AIRFOIL@BASE ***",mesh)
    ob.location = bpy.context.scene.cursor_location
    bpy.context.scene.objects.link(ob)
    mesh.from_pydata(verts,[],faces)
    mesh.update(calc_edges=True)
    bpy.ops.object.select_all(action='DESELECT')    
    for obs in bpy.context.scene.objects:
        if obs.name[0:16] == 'AIRFOIL@BASE ***':
            obs.select = True
            bpy.context.scene.objects.active = obs
        else:
            obs.select = False
    ob = bpy.context.active_object
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.mesh.edge_face_add()
    bpy.ops.object.mode_set(mode='OBJECT')
    bpy.context.object.location[0] = location[0] + inner_space
    bpy.context.object.location[1] = location[1]
    bpy.context.object.location[2] = location[2]
    bpy.context.object.scale[0] = base_washout
    bpy.context.object.scale[1] = base_washout
    bpy.context.object.scale[2] = base_washout

    mesh = bpy.data.meshes.new("AIRFOIL@TIP ***")
    ob = bpy.data.objects.new("AIRFOIL@TIP ***",mesh)
    ob.location = bpy.context.scene.cursor_location
    bpy.context.scene.objects.link(ob)
    mesh.from_pydata(verts,[],faces)
    bpy.ops.object.select_all(action='DESELECT')    
    for obs in bpy.context.scene.objects:
        if obs.name[0:15] == 'AIRFOIL@TIP ***':
            obs.select = True
            bpy.context.scene.objects.active = obs
        else:
            obs.select = False
    ob = bpy.context.active_object
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.mesh.edge_face_add()
    bpy.ops.object.mode_set(mode='OBJECT')
    bpy.context.object.location[0] = location[0] + wing_length + inner_space
    bpy.context.object.location[1] = location[1] + sweep
    bpy.context.object.location[2] = location[2]
    bpy.context.object.scale[0] = tip_washout
    bpy.context.object.scale[1] = tip_washout
    bpy.context.object.scale[2] = tip_washout

    bpy.ops.object.select_all(action='DESELECT')    
    for obs in bpy.context.scene.objects:
        if obs.name[0:8] == 'AIRFOIL@':
            obs.select = True
            bpy.context.scene.objects.active = obs
        else:
            obs.select = False
    bpy.ops.object.join()
    ob = bpy.context.active_object
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.mesh.bridge_edge_loops()
    bpy.ops.object.mode_set(mode='OBJECT')
    ob.name = "FIRST WING ***"
    
    #Second Wing
    mesh = bpy.data.meshes.new("AIRFOIL@BASE ***")
    ob = bpy.data.objects.new("AIRFOIL@BASE ***",mesh)
    ob.location = bpy.context.scene.cursor_location
    bpy.context.scene.objects.link(ob)
    mesh.from_pydata(verts,[],faces)
    mesh.update(calc_edges=True)
    bpy.ops.object.select_all(action='DESELECT')    
    for obs in bpy.context.scene.objects:
        if obs.name[0:16] == 'AIRFOIL@BASE ***':
            obs.select = True
            bpy.context.scene.objects.active = obs
        else:
            obs.select = False
    ob = bpy.context.active_object
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.mesh.edge_face_add()
    bpy.ops.object.mode_set(mode='OBJECT')
    bpy.context.object.location[0] = location[0]
    bpy.context.object.location[1] = location[1]
    bpy.context.object.location[2] = location[2]
    bpy.context.object.scale[0] = base_washout
    bpy.context.object.scale[1] = base_washout
    bpy.context.object.scale[2] = base_washout
    #Second wing airfoil tip
    mesh = bpy.data.meshes.new("AIRFOIL@TIP ***")
    ob = bpy.data.objects.new("AIRFOIL@TIP ***",mesh)
    ob.location = bpy.context.scene.cursor_location
    bpy.context.scene.objects.link(ob)
    mesh.from_pydata(verts,[],faces)
    bpy.ops.object.select_all(action='DESELECT')    
    for obs in bpy.context.scene.objects:
        if obs.name[0:15] == 'AIRFOIL@TIP ***':
            obs.select = True
            bpy.context.scene.objects.active = obs
        else:
            obs.select = False
    ob = bpy.context.active_object
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.mesh.edge_face_add()
    bpy.ops.object.mode_set(mode='OBJECT')
    bpy.context.object.location[0] = location[0] - wing_length
    bpy.context.object.location[1] = location[1] + sweep
    bpy.context.object.location[2] = location[2]
    bpy.context.object.scale[0] = tip_washout
    bpy.context.object.scale[1] = tip_washout
    bpy.context.object.scale[2] = tip_washout
    
    bpy.ops.object.select_all(action='DESELECT')    
    for obs in bpy.context.scene.objects:
        if obs.name[0:8] == 'AIRFOIL@':
            obs.select = True
            bpy.context.scene.objects.active = obs
        else:
            obs.select = False
    bpy.ops.object.join()
    ob = bpy.context.active_object
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.mesh.bridge_edge_loops()
    bpy.ops.object.mode_set(mode='OBJECT')
    ob.name = "SECOND WING ***"
    #Join both wings
    for obs in bpy.context.scene.objects:
        if obs.name[0:14] == 'FIRST WING ***' or \
           obs.name[0:15] == 'SECOND WING ***':
                obs.select = True
                bpy.context.scene.objects.active = obs
        else:
            obs.select = False
    bpy.ops.object.join()
    bpy.ops.object.origin_set(type='GEOMETRY_ORIGIN')
    #Set location
    bpy.context.object.location[0] = location[0]
    bpy.context.object.location[1] = location[1]
    bpy.context.object.location[2] = location[2]
    #Set rotation
    for i in range (0,3):
        rotation[i] = math.radians(rotation[i])
    bpy.context.object.rotation_euler[0] = rotation[0]
    bpy.context.object.rotation_euler[1] = rotation[1]
    bpy.context.object.rotation_euler[2] = rotation[2]
    bpy.context.object.scale[0] = scale[0]
    bpy.context.object.scale[1] = scale[1]
    bpy.context.object.scale[2] = scale[2] 
        
    print("Symmetrical Wings created successfully.")
    print("----------------------------------------")

#Gets CSV points from an input file location 
def useCSV(file_location):
    try:
        print("Using CSV points...")
        #try to get points from excel sheet
        t_pointsCSV = getTauPoints(file_location)
        z_pointsCSV = getZetaPoints(file_location)
        points = [t_pointsCSV, z_pointsCSV]
    except:
        print("File not found at " + file_location + ".")
        points = [False]
        pass
    return points

#The operator class that will take in inputs for generating symmetrical wings
class SymmetricalWings(bpy.types.Operator):
    '''Symmetrical wings generator'''
    bl_idname = "mesh.symmetrical_wings_add"
    bl_label = "Add symmetrical wings"
    bl_options = {'REGISTER', 'UNDO'}
 
    #Properties
    idname = StringProperty(name="Unique Identifier",
                            default = "Symmetrical Wings")
    
    use_csv = BoolProperty(name = "Use CSV",
                           default = False,
                           description = "Use CSV file")
    
    file_location = StringProperty(name="File Location",
                                   default = "C:/wing.csv")
    
    delta = FloatProperty(name="Initial Aft Thickness",
                          default=0.05)
    
    tau_points = StringProperty(name="Tau points",
                                description="Independent variable 'Time'",
                                default="0.0, 0.03, 0.19, 0.50, 0.88, 1.00")
    
    zeta_points = StringProperty(name="Zeta points",
                                 description="User input points",
                                 default="1.0, 0.00, 0.0007, -0.049, 0.00, 0.0488, 0.00, 1.0")
    
    n_points = IntProperty(name="Airfoil Smoothness",
                           description="Number of points on the parametric cubic spline",
                           default = 20, min = 2)
    
    base_washout = FloatProperty(name="Base Washout",
                                 default = 1.0,
                                 min = 0.00)
    
    tip_washout = FloatProperty(name="Tip Washout",
                                default = 0.5,
                                min = 0.00)
    
    sweep = FloatProperty(name="Sweep",
                          default = 0.5,
                          min = 0.00)
    
    wing_length = FloatProperty(name="Adjust wing length",
                                default = 3.2,
                                min = 0.00)
    
    inner_space = FloatProperty(name="Inner Space",
                                default = 1.0,
                                min = 0.00)
    
    location = FloatVectorProperty(name="Location",
                                   default = (0.0, 0.0, 0.0),
                                   subtype='XYZ')
    
    rotation = FloatVectorProperty(name="Rotation",
                                   default = (0.0, 0.0, 0.0),
                                   subtype='XYZ')
    
    scale = FloatVectorProperty(name="Scale",
                                default = (1.0, 1.0, 1.0),
                                subtype='XYZ')
    
    colorwheel = FloatVectorProperty(name="Color",
                                     default = (0.184, 0.174, 0.174),
                                     subtype='COLOR')

    def draw(self, context):
        layout = self.layout
        col = layout.column()
        layout.prop(self, "idname")
        layout.prop(self, "file_location")
        layout.prop(self, "use_csv")
        layout.prop(self, "delta")
        layout.prop(self, "tau_points")
        layout.prop(self, "zeta_points")
        layout.prop(self, "n_points")
        layout.prop(self, "base_washout")
        layout.prop(self, "tip_washout")
        layout.prop(self, "sweep")
        layout.prop(self, "wing_length")
        layout.prop(self, "inner_space")
        layout.prop(self, "location")
        layout.prop(self, "rotation")
        layout.prop(self, "scale")
        layout.prop(self, "colorwheel")
        
    def execute(self, context):
        print("")
        if self.use_csv:
            points = useCSV(self.file_location)
            if points[0] is False:
                bpy.ops.error.error_message('INVOKE_DEFAULT',
                                            message_type = 'FILE_NOT_FOUND')
                return {'FINISHED'}
            self.tau_points = points[0]
            self.zeta_points = points[1]
            #validate points
            if not checkTauZetaOffset(self.tau_points,
                                      self.zeta_points):
                print("TAU ZETA OFFSET > or < 2")
                bpy.ops.error.error_message('INVOKE_DEFAULT',
                                            message_type = 'TAU_ZETA_OFFSET')
                return{'FINISHED'}
            if not validateUserPoints(self.tau_points,
                                      self.zeta_points):
                bpy.ops.error.error_message('INVOKE_DEFAULT',
                                            message_type = 'INVALID_FLOAT')
                return{'FINISHED'}
        elif not checkTauZetaOffset(self.tau_points,
                                    self.zeta_points):
            print("TAU ZETA OFFSET > or < 2")
            bpy.ops.error.error_message('INVOKE_DEFAULT',
                                        message_type = 'TAU_ZETA_OFFSET')
            return{'FINISHED'}
        elif not validateUserPoints(self.tau_points,
                                    self.zeta_points):
            bpy.ops.error.error_message('INVOKE_DEFAULT',
                                        message_type = 'INVALID_FLOAT')
            return {'FINISHED'}
        try:
            ob = add_wings(self.delta,
                           self.tau_points,
                           self.zeta_points,
                           self.base_washout,
                           self.tip_washout,
                           self.sweep,
                           self.wing_length,
                           self.inner_space,
                           self.location,
                           self.rotation,
                           self.scale,
                           self.file_location,
                           self.colorwheel,
                           self.n_points)
        except:
            bpy.ops.error.error_message('INVOKE_DEFAULT',
                                        message_type = 'SINGULAR_MATRIX')
            return {'FINISHED'}
        ob = bpy.context.active_object
        #Check for uniqueness of name
        for obj in context.scene.objects:
            if obj.name == self.idname:
                self.idname = self.idname + "*"
        ob["component"] = "symmetrical wings"
        bpy.types.Object.use_csv = self.use_csv
        ob["file_location"] = self.file_location
        ob["delta"] = self.delta
        ob["tau_points"] = self.tau_points
        ob["zeta_points"] = self.zeta_points
        ob["n_points"] = self.n_points
        ob["base_washout"] = self.base_washout
        ob["tip_washout"] = self.tip_washout
        ob["sweep"] = self.sweep
        ob["wing_length"] = self.wing_length
        ob["inner_space"] = self.inner_space
        ob.name = self.idname
        ob["identifier"] = self.idname
        ob["colorwheel"] = self.colorwheel
        bpy.ops.object.material_slot_remove()
        color = makeMaterial('Color', self.colorwheel, (1,1,1), 1)
        setMaterial(bpy.context.object, color)
        bpy.ops.view3d.obj_search_refresh()
        return {'FINISHED'}

    def invoke(self, context, event):
        wm = context.window_manager
        return wm.invoke_props_dialog(self)

#Operator class to update an existing pair of symmetrical wings
class updateSymmetricalWing(bpy.types.Operator):
    bl_idname = "mesh.symmetrical_wings_update"
    bl_label = "Update symmetrical wings"
    bl_options = {'INTERNAL'}

    def execute(self, context):
        print("")
        wm = context.window_manager.MyProperties
        scn = context.scene
        for obj in scn.objects:
            if obj.select == True:
                ob = obj
                break
        if not checkTauZetaOffset(ob["tau_points"],
                                  ob["zeta_points"]):
            print("TAU ZETA OFFSET > or < 2")
            bpy.ops.error.error_message('INVOKE_DEFAULT',
                                        message_type = 'TAU_ZETA_OFFSET')
            return{'FINISHED'}
        if not validateUserPoints(ob["tau_points"],
                                  ob["zeta_points"]):
            bpy.ops.error.error_message('INVOKE_DEFAULT',
                                        message_type = 'INVALID_FLOAT')
            return {'FINISHED'}
        if(ob["delta"] < 0 or \
           ob["n_points"] < 0 or \
           ob["base_washout"] < 0 or \
           ob["tip_washout"] < 0 or \
           ob["wing_length"] < 0 or \
           ob["inner_space"] < 0):
                bpy.ops.error.error_message('INVOKE_DEFAULT',
                                            message_type = 'NEGATIVE_VALUE')
                return {'FINISHED'}
        try:
            newOb = add_wings(ob["delta"],
                              ob["tau_points"],
                              ob["zeta_points"],
                              ob["base_washout"],
                              ob["tip_washout"],
                              ob["sweep"],
                              ob["wing_length"],
                              ob["inner_space"],
                              ob.location,
                              ob.rotation_euler,
                              ob.scale,
                              ob["file_location"],
                              ob["colorwheel"],
                              ob["n_points"])
        except:
            bpy.ops.error.error_message('INVOKE_DEFAULT',
                                        message_type = 'SINGULAR_MATRIX')
            return {'FINISHED'}
        newOb = bpy.context.active_object
        #Convert radians back to degrees
        for i in range(0,3):
            ob.rotation_euler[i] = ob.rotation_euler[i] * RADIANS_TO_DEGREES
        newOb.rotation_euler = ob.rotation_euler
        holder = ob.name
        newOb["component"] = "symmetrical wings"
        newOb["delta"] = ob["delta"]
        newOb["tau_points"] = ob["tau_points"]
        newOb["zeta_points"] = ob["zeta_points"]
        newOb["n_points"] = ob["n_points"]
        newOb["base_washout"] = ob["base_washout"]
        newOb["tip_washout"] = ob["tip_washout"]
        newOb["sweep"] = ob["sweep"]
        newOb["wing_length"] = ob["wing_length"]
        newOb["inner_space"] = ob["inner_space"]
        newOb["file_location"] = ob["file_location"]
        bpy.types.Object.use_csv = ob.use_csv
        newOb["colorwheel"] = ob["colorwheel"]
        ob.select = True
        newOb.select = False
        bpy.ops.object.delete()
        newOb.name = holder
        newOb = bpy.context.active_object
        color = makeMaterial('Color', newOb["colorwheel"], (1,1,1), 1)
        setMaterial(bpy.context.object, color)
        wm.srch_index = -1
        bpy.ops.view3d.obj_search_refresh()
        return {'FINISHED'}

#Operator class to delete a pair of symmetrical wings
class deleteSymmetricalWings(bpy.types.Operator):
    bl_idname = "mesh.symmetrical_wings_delete"
    bl_label = "Delete symmetrical wings? (Click elsewhere to cancel.)"
    bl_options = {'INTERNAL'}

    def invoke(self, context, event):
        wm = context.window_manager
        return wm.invoke_props_dialog(self)

    def execute(self, context):
        wm = context.window_manager.MyProperties
        scn = context.scene
        for obj in scn.objects:
            if obj.select == True:
                ob = obj
        bpy.ops.object.delete()
        wm.srch_index = -1
        bpy.ops.view3d.obj_search_refresh()
        return {'FINISHED'}

#Operator class to add color to a component 
class symmetricalWingsColor(bpy.types.Operator):
    bl_idname = "mesh.symmetrical_wings_color"
    bl_label = "Add Color"
    bl_options = {'INTERNAL'}

    colorwheel = FloatVectorProperty(name="Color",
                                     default = (0.184, 0.174, 0.174),
                                     subtype='COLOR')

    def invoke(self, context, event):
        wm = context.window_manager
        return wm.invoke_props_dialog(self)

    def execute(self, context):
        wm = context.window_manager.MyProperties
        scn = context.scene
        for obj in scn.objects:
            if obj.select == True:
                ob = obj
        bpy.ops.object.material_slot_remove()        
        color = makeMaterial('Color', self.colorwheel, (1,1,1), 1)
        setMaterial(bpy.context.object, color)
        ob["colorwheel"] = self.colorwheel
        wm.srch_index = -1
        bpy.ops.view3d.obj_search_refresh()
        return {'FINISHED'}
    
 
#Operator class to export data to CSV
class exportSymmetricalWings(bpy.types.Operator):
    bl_idname = "mesh.symmetrical_wings_export"
    bl_label = "Export data to CSV? (Click elsewhere to cancel.)"
    bl_options = {'INTERNAL'}
        
    def invoke(self, context, event):
        wm = context.window_manager
        return wm.invoke_props_dialog(self)

    def execute(self, context):
        wm = context.window_manager.MyProperties
        scn = context.scene
        for obj in scn.objects:
            if obj.select == True:
                ob = obj
        file_export = ob['file_location']
        with open(file_export, 'w', newline = '') as f:
            writer = csv.writer(f)
            exportTau = ob['tau_points']
            exportTau = exportTau.split(',')
            exportTau.append('')
            exportTau.append('')
            exportZeta = ob['zeta_points']
            exportZeta = exportZeta.split(',')
            writer.writerow(['Tau', 'Zeta'])
            for i in range(0, len(exportZeta)): 
                writer.writerow([exportTau[i], exportZeta[i]])
            f.close()
        return {'FINISHED'}
  
